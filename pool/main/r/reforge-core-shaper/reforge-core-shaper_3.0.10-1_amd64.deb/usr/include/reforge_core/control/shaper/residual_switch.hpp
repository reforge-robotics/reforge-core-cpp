#pragma once

#include <cstddef>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "reforge_core/control/shaper/config.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"
#include "reforge_core/util/timing/joint_limits.hpp"
#include "reforge_core/util/timing/joint_trajectory.hpp"

namespace reforge::control::shaper {

/** Identify the optimizer that produced a residual-switch candidate. */
enum class ResidualSwitchCandidateSource {
    kCommandSpace,
    kModalAware,
};

/** Record one ordered residual-switch solve attempt. */
struct REFORGE_SHAPER_EXPORT ResidualSwitchAttemptDiagnostics final {
    std::size_t duration_samples = 0;
    double coarse_period_s = 0.0;
    std::string status;
    std::size_t ordinal = 0;
};

/** Record one exact attach-point mode used by residual search. */
struct REFORGE_SHAPER_EXPORT ResidualFallbackModalDiagnostics final {
    std::size_t axis = 0;
    double natural_frequency_rad_s = 0.0;
    double frequency_hz = 0.0;
    double damping_ratio = 0.0;
    double samples_per_cycle = 0.0;
    std::vector<std::string> flags;
};

/** Store smoothness, timing, limit, and residual evidence for one candidate. */
struct REFORGE_SHAPER_EXPORT ResidualSwitchCandidateDiagnostics final {
    std::size_t duration_samples = 0;
    std::size_t switch_start_index = 0;
    std::vector<double> peak_jerk_rad_s3;
    std::vector<double> switch_start_acceleration_jump_rad_s2;
    std::vector<double> attach_acceleration_jump_rad_s2;
    std::optional<std::vector<double>> acceleration_limit_margin_rad_s2;
    std::optional<std::vector<double>> velocity_limit_margin_rad_s;
    std::optional<double> extra_duration_fraction;
    std::optional<double> normalized_terminal_residual_energy;
    std::optional<std::map<std::size_t, double>>
        terminal_rms_residual_by_axis_rad;
    std::optional<std::map<std::size_t, double>>
        terminal_peak_residual_by_axis_rad;
    std::optional<std::string> smoothness_rejection_reason;
    ResidualSwitchCandidateSource source =
        ResidualSwitchCandidateSource::kCommandSpace;
    std::optional<std::size_t> optimization_sample_count;
    std::optional<std::size_t> qp_variable_count;
    std::optional<std::size_t> qp_constraint_count;
    std::optional<std::size_t> qp_matrix_storage_bytes;
    std::optional<std::size_t> native_sample_count;
    std::optional<double> planning_time_s;
    std::optional<double> preparation_time_s;
    std::optional<double> assembly_time_s;
    std::optional<double> conic_conversion_time_s;
    std::optional<double> solve_time_s;
    std::optional<double> solver_setup_time_s;
    std::optional<double> solver_iteration_time_s;
    std::optional<bool> solver_cache_hit;
    std::optional<double> solver_update_time_s;
    std::optional<std::size_t> solver_cache_hits;
    std::optional<std::size_t> solver_cache_misses;
    std::optional<std::size_t> solver_cache_entry_count;
    std::optional<std::size_t> solver_cache_estimated_bytes;
    std::optional<double> reconstruction_and_validation_time_s;
    std::optional<std::vector<double>> position_limit_margin_rad;
    std::optional<std::vector<double>> jerk_limit_margin_rad_s3;
    std::optional<std::vector<double>>
        continuous_jerk_limit_margin_rad_s3;
};

/** Summarize bounded candidate search and its selected candidate.
 *
 * Search timing fields measure synchronous phase wall time. The scan duration
 * is zero when no residual-optimal scan runs. Attempt ordinals are one-based
 * positions in the ordered duration-attempt list.
 * Window timing fields report post-solve qualification of synchronous work.
 * They do not imply that solver execution was interrupted or deterministically
 * bounded by the emission deadline.
 */
struct REFORGE_SHAPER_EXPORT ResidualSwitchSearchDiagnostics final {
    std::size_t attempts = 0;
    std::size_t seed_duration_samples = 0;
    std::optional<ResidualSwitchCandidateDiagnostics> selected_candidate;
    std::vector<ResidualSwitchCandidateDiagnostics> candidates;
    std::vector<std::string> fallback_reasons;
    std::vector<std::size_t> attempted_duration_samples;
    std::vector<std::string> attempt_outcomes;
    std::optional<double> window_solve_time_s;
    std::optional<double> window_deadline_s;
    std::optional<double> window_deadline_margin_s;
    std::optional<bool> window_timing_qualified;
    std::optional<std::string> fallback_action;
    std::optional<std::string> fallback_reason;
    std::optional<std::string> failure_stage;
    std::optional<std::string> fallback_detail;
    std::vector<ResidualSwitchAttemptDiagnostics> attempt_details;
    std::vector<ResidualFallbackModalDiagnostics> attach_point_modes;
    std::optional<double> cascade_sample_period_s;
    std::optional<double> cascade_spectral_radius;
    std::optional<std::size_t> selected_candidate_ordinal;
    std::optional<double> adaptive_feasibility_time_s;
    std::optional<double> candidate_scan_time_s;
};

/** Own one residual-switch search request. */
struct REFORGE_SHAPER_EXPORT ResidualSwitchRequest final {
    reforge::util::timing::JointTrajectory raw_trajectory;
    reforge::util::timing::JointTrajectory shaped_trajectory;
    std::size_t attach_index = 0;
    std::size_t latest_start_index = 0;
    std::size_t earliest_start_index = 0;
    double advance_s = 0.0;
    double shaping_weight = 0.0;
    reforge::util::timing::JointStateLimits state_limits;
    std::size_t search_resolution_samples = 1;
    std::size_t max_qp_attempts = 1;
    double tracking_weight = 0.0;
    double acceleration_weight = 1.0;
    double jerk_weight = 0.01;
    std::optional<double> max_extra_duration_fraction;
    std::optional<double> raw_command_duration_s;
    std::optional<std::size_t> output_stop_index;
    std::vector<reforge::native::Matrix> modal_params_by_axis;
    std::optional<ResidualSwitchModalConfig> modal_config;
    std::optional<std::size_t> initial_duration_samples;
    ResidualSwitchSearchPolicy search_policy =
        kDefaultResidualSwitchSearchPolicy;
};

/** Own one solved switch segment and its source start index. */
struct REFORGE_SHAPER_EXPORT ResidualSwitchSolution final {
    std::size_t start_index = 0;
    reforge::util::timing::JointTrajectory trajectory;
};

/** Own one selected solution and complete search diagnostics. */
struct REFORGE_SHAPER_EXPORT ResidualSwitchPlanResult final {
    ResidualSwitchSolution solution;
    ResidualSwitchSearchDiagnostics diagnostics;
};

/** Plan deterministic constrained residual switches and own latest diagnostics.
 *
 * One planner instance is not safe for concurrent calls. Independent requests
 * must use independent planner instances.
 */
class REFORGE_SHAPER_EXPORT ResidualSwitchPlanner final {
public:
    /**
     * Construct a planner for one positive native sample period [s].
     *
     * Candidate workers are used only for the independent residual-optimal
     * scan after adaptive feasibility search. A value of one preserves the
     * serial execution path.
     */
    explicit ResidualSwitchPlanner(
        double sample_time_s,
        std::size_t candidate_worker_count =
            kDefaultResidualSwitchCandidateWorkers);
    ~ResidualSwitchPlanner();
    ResidualSwitchPlanner(ResidualSwitchPlanner&&) noexcept;
    ResidualSwitchPlanner& operator=(ResidualSwitchPlanner&&) noexcept;
    ResidualSwitchPlanner(const ResidualSwitchPlanner&) = delete;
    ResidualSwitchPlanner& operator=(const ResidualSwitchPlanner&) = delete;

    /** Clear latest diagnostics without changing immutable configuration. */
    void Reset();

    /** Search for and select one constrained switch. */
    [[nodiscard]] ResidualSwitchPlanResult Plan(
        const ResidualSwitchRequest& request);

    /** Return the latest completed search diagnostics, if any. */
    [[nodiscard]] const std::optional<ResidualSwitchSearchDiagnostics>&
    latest_diagnostics() const noexcept;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace reforge::control::shaper
