#pragma once

#include <optional>
#include <vector>

#include "reforge_core/control/runtime/modal_inference.hpp"
#include "reforge_core/control/runtime/weighting.hpp"
#include "reforge_core/control/shaper/config.hpp"
#include "reforge_core/control/shaper/modal_inference_strategy.hpp"
#include "reforge_core/control/shaper/windowing.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::shaper::backend {

/** Own one complete vector-valued shaped controller sample. */
struct REFORGE_SHAPER_EXPORT ShapedSample final {
    reforge::native::Vector position_rad;
    reforge::native::Vector velocity_rad_s;
    reforge::native::Vector acceleration_rad_s2;
};

/** Configure one stateful joint-sample operation. */
struct REFORGE_SHAPER_EXPORT ProcessSampleRequest final {
    reforge::native::Vector position_rad;
    std::optional<reforge::native::Vector> velocity_rad_per_s;
    std::optional<reforge::native::Vector> acceleration_rad_per_s2;
    double vibration_shaping_weight = 1.0;
    std::optional<double> vibration_weight_transition_s = 0.1;
    double vibration_weight_rate_per_s =
        reforge::control::runtime::kDefaultVibrationWeightRatePerS;
    double max_transition_s =
        reforge::control::runtime::kMaxVibrationWeightTransitionS;
    reforge::control::shaper::ModalInferenceStrategy
        modal_inference_strategy =
            reforge::control::shaper::ModalInferenceStrategy::kFixed;
};

/** Own one finite joint command and optional derivative/time caches. */
struct REFORGE_SHAPER_EXPORT JointTrajectoryInput final {
    reforge::native::Matrix position_rad;
    std::optional<reforge::native::Matrix> velocity_rad_per_s;
    std::optional<reforge::native::Matrix> acceleration_rad_per_s2;
    std::optional<reforge::native::Vector> time_s;
};

/** Configure one finite joint-trajectory shaping operation. */
struct REFORGE_SHAPER_EXPORT ProcessTrajectoryRequest final {
    JointTrajectoryInput input;
    double vibration_shaping_weight = 1.0;
    std::optional<reforge::native::Vector> vibration_shaping_weight_profile;
    std::optional<reforge::control::shaper::ResidualShapingStrategy>
        residual_shaping_strategy =
            reforge::control::shaper::ResidualShapingStrategy::kAlignedTail;
    std::optional<reforge::control::shaper::ResidualSwitchLimits>
        residual_switch_limits;
    double residual_transition_margin_s = 0.0;
    bool finalize_tail = true;
    bool reset_on_discontinuity = true;
    std::optional<reforge::control::runtime::AxisParams>
        fixed_modal_params_by_axis;
    reforge::control::shaper::ModalInferenceStrategy
        modal_inference_strategy =
            reforge::control::shaper::ModalInferenceStrategy::kFixed;
};

}  // namespace reforge::control::shaper::backend
