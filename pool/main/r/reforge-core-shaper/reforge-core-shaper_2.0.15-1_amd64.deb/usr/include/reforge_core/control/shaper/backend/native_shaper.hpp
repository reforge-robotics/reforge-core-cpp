#pragma once

#include <memory>
#include <optional>
#include <tuple>
#include <utility>
#include <vector>

#include "reforge_core/control/runtime/modal_inference.hpp"
#include "reforge_core/control/runtime/task_space.hpp"
#include "reforge_core/control/shaper/backend/backend_configuration.hpp"
#include "reforge_core/control/shaper/backend/backend_requests.hpp"
#include "reforge_core/control/shaper/residual_switch.hpp"
#include "reforge_core/control/window/shaper_window_handle.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::shaper::backend {

/** Own the complete Python-independent native shaper session.
 *
 * The session is mutable and is not concurrently callable. All returned arrays
 * and fitted-mode values are detached from backend workspaces.
 */
class REFORGE_SHAPER_EXPORT NativeShaper final
    : public reforge::control::shaper::ShaperWindowRuntime,
      public reforge::control::shaper::TaskSpaceWindowRuntime {
public:
    /** Load immutable resources and assemble all joint-path runtime state.
     *
     * Args:
     *     configuration: Validated construction inputs and resource identities.
     */
    explicit NativeShaper(BackendConfiguration configuration);
    ~NativeShaper();
    NativeShaper(NativeShaper&&) noexcept;
    NativeShaper& operator=(NativeShaper&&) noexcept;
    NativeShaper(const NativeShaper&) = delete;
    NativeShaper& operator=(const NativeShaper&) = delete;

    /** Return the immutable normalized construction configuration. */
    [[nodiscard]] const BackendConfiguration& Configuration() const noexcept;

    /** Return the effective complete-native capabilities. */
    [[nodiscard]] const BackendCapabilities& Capabilities() const noexcept;

    /** Return the most recently emitted raw-to-shaped blend weight. */
    [[nodiscard]] double CurrentVibrationShapingWeight() const noexcept
        override;

    /** Return the latest residual-switch diagnostics, if any. */
    [[nodiscard]] std::optional<
        reforge::control::shaper::ResidualSwitchSearchDiagnostics>
    LastResidualSwitchDiagnostics() const;

    /** Reset modal, shaping, residual, and input-continuity state. */
    void Reset() override;

    /** Idempotently release the session after closing future child owners. */
    void Close() noexcept;

    /** Return TCP position `[3]` [m] for one joint configuration. */
    [[nodiscard]] reforge::native::Vector ComputeForwardKinematics(
        const reforge::native::Vector& joint_angles_rad);

    /** Return diagonal joint inertia values [kg m²]. */
    [[nodiscard]] reforge::native::Vector ComputeInertia(
        const reforge::native::Vector& joint_angles_rad);

    /** Convert Cartesian position to vertical angle [rad] and radius [m]. */
    [[nodiscard]] std::pair<double, double> CartesianToPolar(
        const reforge::native::Vector& xyz_m) const;

    /** Differentiate a sample-major matrix once on the native sample grid. */
    [[nodiscard]] reforge::native::Matrix FiniteDifferenceFirst(
        const reforge::native::Matrix& samples) const;

    /** Differentiate first derivatives on the native sample grid. */
    [[nodiscard]] reforge::native::Matrix FiniteDifferenceSecond(
        const reforge::native::Matrix& first) const;

    /** Return polar coordinates and inertia for one model state. */
    [[nodiscard]] std::tuple<
        double,
        double,
        reforge::native::Vector>
    ComputeNnInputs(
        const reforge::control::runtime::RobotState& state,
        std::optional<reforge::native::Vector> train_base_angles_rad =
            std::nullopt);

    /** Return one owned float feature matrix per state. */
    [[nodiscard]] std::vector<reforge::native::FloatMatrix>
    BuildShaperFeatureTensor(
        const std::vector<reforge::control::runtime::RobotState>& states);

    /** Infer fitted modes for one state. */
    [[nodiscard]] std::vector<reforge::control::runtime::FittedAxisModes>
    InferFittedModes(
        const reforge::control::runtime::RobotState& state);

    /** Infer fitted modes in source sample order. */
    [[nodiscard]] std::vector<
        std::vector<reforge::control::runtime::FittedAxisModes>>
    InferFittedModeSequence(
        const std::vector<reforge::control::runtime::RobotState>& states);

    /** Shape and commit one stream sample transactionally. */
    [[nodiscard]] ShapedSample ProcessSample(
        const ProcessSampleRequest& request);

    /** Shape one stream sample at full weight. */
    [[nodiscard]] ShapedSample ShapeSample(
        reforge::native::Vector command_rad,
        std::optional<reforge::native::Vector> command_velocity_rad_s =
            std::nullopt,
        std::optional<reforge::native::Vector> command_acceleration_rad_s2 =
            std::nullopt,
        reforge::control::shaper::ModalInferenceStrategy strategy =
            reforge::control::shaper::ModalInferenceStrategy::kFixed);

    /** Shape and commit one finite joint trajectory. */
    [[nodiscard]] reforge::native::ShapedTrajectory ProcessTrajectory(
        const ProcessTrajectoryRequest& request);

    /** Shape one finite joint trajectory at full weight. */
    [[nodiscard]] reforge::native::ShapedTrajectory ShapeTrajectory(
        reforge::native::Matrix command_rad,
        std::optional<reforge::native::Matrix> command_velocity_rad_s =
            std::nullopt,
        std::optional<reforge::native::Matrix> command_acceleration_rad_s2 =
            std::nullopt,
        std::optional<reforge::native::Vector> time_s = std::nullopt,
        std::optional<reforge::control::shaper::ResidualShapingStrategy>
            residual_shaping_strategy =
                reforge::control::shaper::ResidualShapingStrategy::kAlignedTail,
        reforge::control::shaper::ModalInferenceStrategy strategy =
            reforge::control::shaper::ModalInferenceStrategy::kFixed);

    /** Shape one complete task-space trajectory with native or injected IK.
     *
     * The optional solver is borrowed only for the duration of this call. An
     * omitted solver selects the Python-independent built-in dynamics adapter.
     */
    [[nodiscard]] reforge::control::window::TaskSpaceShapedTrajectory
    ProcessTaskSpaceTrajectory(
        const reforge::control::shaper::TaskSpaceWindowRequest& request)
        override;

    /** Shape task space with one borrowed binding-only IK implementation. */
    [[nodiscard]] reforge::control::window::TaskSpaceShapedTrajectory
    ProcessTaskSpaceTrajectoryWithSolver(
        const reforge::control::shaper::TaskSpaceWindowRequest& request,
        reforge::control::runtime::TaskSpaceIkSolver& ik_solver) override;

    /** Create one backend-registered joint window session.
     *
     * The returned handle owns a separate complete native producer runtime.
     * Closing this backend closes the handle before releasing session
     * resources.
     */
    [[nodiscard]] std::unique_ptr<
        reforge::control::window::TrajectoryWindowHandle>
    CreateWindowedBuffer(
        const reforge::control::shaper::ShaperWindowRequest& request);

    /** Qualify one fixed joint-window duration on an isolated runtime. */
    [[nodiscard]] reforge::control::shaper::ShaperWindowQualificationResult
    QualifyWindowedBuffer(
        const reforge::control::shaper::ShaperWindowRequest& request,
        double compute_fraction_limit);

    /** Select the first qualifying joint-window duration in source order. */
    [[nodiscard]] reforge::control::shaper::ShaperWindowQualificationResult
    SelectQualifiedWindow(
        const reforge::control::shaper::ShaperWindowRequest& request,
        const std::vector<double>& window_candidates_s,
        double compute_fraction_limit);

    /** Create one backend-registered precomputed task-space window session. */
    [[nodiscard]] std::unique_ptr<
        reforge::control::window::TaskSpaceWindowHandle>
    CreateTaskSpaceWindowedBuffer(
        const reforge::control::shaper::TaskSpaceWindowRequest& request);

    /** Create a registered task window with one borrowed explicit IK solver. */
    [[nodiscard]] std::unique_ptr<
        reforge::control::window::TaskSpaceWindowHandle>
    CreateTaskSpaceWindowedBufferWithSolver(
        const reforge::control::shaper::TaskSpaceWindowRequest& request,
        reforge::control::runtime::TaskSpaceIkSolver& ik_solver);

    /** Return the controller period consumed by native window services. */
    [[nodiscard]] double SampleTimeS() const noexcept override;

    /** Return the public joint count consumed by native window services. */
    [[nodiscard]] std::size_t NumJoints() const noexcept override;

    /** Return the configured quiet-region residual requirement. */
    [[nodiscard]] bool
    RequireZeroAccelerationRegion() const noexcept override;

    /** Encode window commands as opaque state rows. */
    [[nodiscard]] reforge::native::Matrix GenerateStates(
        const reforge::native::Matrix& command_rad) override;

    /** Select one fixed modal snapshot for a complete source trajectory. */
    [[nodiscard]] std::vector<reforge::native::Matrix>
    SelectFixedModalSnapshot(
        const reforge::native::Matrix& states,
        const reforge::native::Matrix& path_velocity_rad_s,
        const reforge::native::Matrix& path_acceleration_rad_s2) override;

    /** Select the exact residual attach-point modal snapshot. */
    [[nodiscard]] std::vector<reforge::native::Matrix>
    SelectResidualModalSnapshot(
        const reforge::native::Matrix& states,
        const reforge::native::Matrix& path_velocity_rad_s,
        const reforge::native::Matrix& path_acceleration_rad_s2,
        std::size_t attach_index,
        reforge::control::shaper::ModalInferenceStrategy
            modal_inference_strategy,
        const std::vector<reforge::native::Matrix>&
            fixed_modal_params_by_axis) override;

    /** Project sample columns to the configured residual path axes. */
    [[nodiscard]] reforge::native::Matrix ResidualPathValues(
        const reforge::native::Matrix& values) const override;

    /** Shape one finite source window without resetting continuation. */
    [[nodiscard]] reforge::native::ShapedTrajectory ProcessWindow(
        const reforge::control::window::TrajectoryWindow& window,
        double vibration_shaping_weight,
        const std::optional<reforge::native::Vector>& weight_profile,
        const std::vector<reforge::native::Matrix>&
            fixed_modal_params_by_axis,
        reforge::control::shaper::ModalInferenceStrategy
            modal_inference_strategy) override;

    /** Drain every remaining joint-shaper sample. */
    [[nodiscard]] reforge::native::ShapedTrajectory FinalizeTail(
        const reforge::native::Vector& last_position_rad,
        double last_time_s,
        std::size_t start_index) override;

    /** Drain one bounded joint-shaper tail chunk. */
    [[nodiscard]] reforge::native::ShapedTrajectory ShapeTailChunk(
        const reforge::native::Vector& last_position_rad,
        double last_time_s,
        std::size_t start_index,
        std::size_t sample_count,
        const std::vector<std::size_t>& remaining_by_axis) override;

    /** Return the latest shaped joint position or a caller fallback. */
    [[nodiscard]] reforge::native::Vector LastShapedPosition(
        const reforge::native::Vector& fallback_position_rad) const override;

    /** Return active delayed support for every shaped joint axis. */
    [[nodiscard]] std::vector<std::size_t>
    TailSupportSamples() const override;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace reforge::control::shaper::backend
