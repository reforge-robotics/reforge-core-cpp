#pragma once

#include <cstddef>
#include <optional>
#include <utility>

#include "reforge_core/control/shaper/residual_switch_config.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::shaper {

inline constexpr double kDefaultResidualSwitchWindowTargetMarginS = 0.0;
inline constexpr double kDefaultResidualSwitchSearchResolutionS = 0.1;
inline constexpr std::size_t kDefaultResidualSwitchMaxQpAttempts = 10;
inline constexpr double kDefaultResidualSwitchTrackingWeight = 1.0;
inline constexpr double kDefaultModalTrackingWeight = 0.0;
inline constexpr double kDefaultModalAccelerationWeight = 1.0;
inline constexpr double kDefaultModalJerkWeight = 0.01;

/** Configure constrained raw-to-shaped residual switching.
 *
 * Default construction creates a fresh modal configuration. Assigning
 * `std::nullopt` to `modal_config` explicitly selects command-space planning.
 */
struct REFORGE_SHAPER_EXPORT ResidualSwitchLimits final {
    std::optional<reforge::native::Vector> max_velocity_rad_s;
    std::optional<reforge::native::Vector> max_acceleration_rad_s2;
    std::optional<reforge::native::Vector> max_jerk_rad_s3;
    std::optional<double> max_extra_duration_fraction;
    std::optional<std::pair<
        reforge::native::Vector,
        reforge::native::Vector>>
        position_bounds_rad;
    std::optional<double> max_search_s;
    std::optional<double> initial_duration_fraction;
    double window_target_margin_s =
        kDefaultResidualSwitchWindowTargetMarginS;
    double search_resolution_s =
        kDefaultResidualSwitchSearchResolutionS;
    std::size_t max_qp_attempts =
        kDefaultResidualSwitchMaxQpAttempts;
    double tracking_weight = kDefaultResidualSwitchTrackingWeight;
    double acceleration_weight = kDefaultModalAccelerationWeight;
    double jerk_weight = kDefaultModalJerkWeight;
    std::optional<ResidualSwitchModalConfig> modal_config =
        ResidualSwitchModalConfig{};
};

}  // namespace reforge::control::shaper
