#pragma once

#include <optional>
#include <variant>
#include <vector>

#include "reforge_core/native/common/export.hpp"

namespace reforge::control::shaper {

inline constexpr double kDefaultModalOptimizationFrequencyHz = 250.0;
inline constexpr double kDefaultResidualSwitchModalObjectiveWeight = 100000.0;
inline constexpr double kDefaultResidualSwitchModalTerminalHorizonS = 0.5;
using TerminalResidualBound = std::variant<double, std::vector<double>>;

/** Store validated fitted-modal residual-switch optimization settings. */
class REFORGE_SHAPER_EXPORT ResidualSwitchModalConfig final {
public:
    /** Construct immutable residual-switch settings.
     *
     * Args:
     *     objective_weight: Nonnegative terminal residual objective weight.
     *     terminal_horizon_s: Positive held-command prediction horizon [s].
     *     optimization_frequency_hz: Optional positive target optimization
     *         rate [Hz]. An omitted value uses the reciprocal of the native
     *         input sample period.
     *     max_terminal_residual_rad: Optional nonnegative scalar or nonempty
     *         per-axis residual ceiling [rad].
     *
     * Raises:
     *     InvalidArgumentError: If a value is non-finite or outside its valid
     *         range.
     */
    ResidualSwitchModalConfig(
        double objective_weight =
            kDefaultResidualSwitchModalObjectiveWeight,
        double terminal_horizon_s =
            kDefaultResidualSwitchModalTerminalHorizonS,
        std::optional<double> optimization_frequency_hz = std::nullopt,
        std::optional<TerminalResidualBound> max_terminal_residual_rad =
            std::nullopt);

    /** Return the terminal fitted-modal residual objective weight. */
    [[nodiscard]] double objective_weight() const noexcept {
        return objective_weight_;
    }

    /** Return the held-command prediction horizon [s]. */
    [[nodiscard]] double terminal_horizon_s() const noexcept {
        return terminal_horizon_s_;
    }

    /** Return the optional explicit target optimization rate [Hz]. */
    [[nodiscard]] const std::optional<double>& optimization_frequency_hz()
        const noexcept {
        return optimization_frequency_hz_;
    }

    /** Resolve the explicit or native-rate optimization frequency.
     *
     * Args:
     *     sample_time_s: Native input trajectory sample period [s].
     *
     * Returns:
     *     Positive modal optimization frequency [Hz].
     *
     * Raises:
     *     InvalidArgumentError: If `sample_time_s` is not finite and positive.
     */
    [[nodiscard]] double ResolveOptimizationFrequencyHz(
        double sample_time_s) const;

    /** Return the optional scalar or per-axis residual ceiling [rad]. */
    [[nodiscard]] const std::optional<TerminalResidualBound>&
    max_terminal_residual_rad() const noexcept {
        return max_terminal_residual_rad_;
    }

private:
    double objective_weight_;
    double terminal_horizon_s_;
    std::optional<double> optimization_frequency_hz_;
    std::optional<TerminalResidualBound> max_terminal_residual_rad_;
};

}  // namespace reforge::control::shaper
