# Reforge Core Shaper C++ SDK

Package: `reforge-core-shaper`
Version: `2.0.15-1`
Architecture: `amd64`

This package installs the Reforge Shaper C++ headers, shared
libraries, CMake package files, and hardware-free demos.

Build and run the installed runtime demo with:

```bash
cmake -S /usr/share/reforge-core-shaper/examples -B /tmp/reforge-shaper-demo
cmake --build /tmp/reforge-shaper-demo --parallel
/tmp/reforge-shaper-demo/reforge_shaper_demo
```

The expected success line is:

```text
Reforge Shaper C++ demo complete.
```

Build and run the complete backend demo with:

```bash
cmake -S /usr/share/reforge-core-shaper/examples/backend -B /tmp/reforge-shaper-backend-demo
cmake --build /tmp/reforge-shaper-backend-demo --parallel
/tmp/reforge-shaper-backend-demo/reforge_shaper_backend_demo
```

The expected backend success line is:

```text
Reforge Shaper backend demo complete.
```
