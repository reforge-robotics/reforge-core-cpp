#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ReforgeShaper::common" for configuration "Release"
set_property(TARGET ReforgeShaper::common APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ReforgeShaper::common PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_common.so"
  IMPORTED_SONAME_RELEASE "libreforge_shaper_common.so"
  )

list(APPEND _cmake_import_check_targets ReforgeShaper::common )
list(APPEND _cmake_import_check_files_for_ReforgeShaper::common "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_common.so" )

# Import target "ReforgeShaper::trajectory" for configuration "Release"
set_property(TARGET ReforgeShaper::trajectory APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ReforgeShaper::trajectory PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_trajectory.so"
  IMPORTED_SONAME_RELEASE "libreforge_shaper_trajectory.so"
  )

list(APPEND _cmake_import_check_targets ReforgeShaper::trajectory )
list(APPEND _cmake_import_check_files_for_ReforgeShaper::trajectory "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_trajectory.so" )

# Import target "ReforgeShaper::model" for configuration "Release"
set_property(TARGET ReforgeShaper::model APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ReforgeShaper::model PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_model.so"
  IMPORTED_SONAME_RELEASE "libreforge_shaper_model.so"
  )

list(APPEND _cmake_import_check_targets ReforgeShaper::model )
list(APPEND _cmake_import_check_files_for_ReforgeShaper::model "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_model.so" )

# Import target "ReforgeShaper::dynamics" for configuration "Release"
set_property(TARGET ReforgeShaper::dynamics APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ReforgeShaper::dynamics PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_dynamics.so"
  IMPORTED_SONAME_RELEASE "libreforge_shaper_dynamics.so"
  )

list(APPEND _cmake_import_check_targets ReforgeShaper::dynamics )
list(APPEND _cmake_import_check_files_for_ReforgeShaper::dynamics "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_dynamics.so" )

# Import target "ReforgeShaper::runtime" for configuration "Release"
set_property(TARGET ReforgeShaper::runtime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ReforgeShaper::runtime PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "ReforgeShaper::dynamics;ReforgeShaper::model"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_runtime.so"
  IMPORTED_SONAME_RELEASE "libreforge_shaper_runtime.so"
  )

list(APPEND _cmake_import_check_targets ReforgeShaper::runtime )
list(APPEND _cmake_import_check_files_for_ReforgeShaper::runtime "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_runtime.so" )

# Import target "ReforgeShaper::window" for configuration "Release"
set_property(TARGET ReforgeShaper::window APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ReforgeShaper::window PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_window.so"
  IMPORTED_SONAME_RELEASE "libreforge_shaper_window.so"
  )

list(APPEND _cmake_import_check_targets ReforgeShaper::window )
list(APPEND _cmake_import_check_files_for_ReforgeShaper::window "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_window.so" )

# Import target "ReforgeShaper::solver" for configuration "Release"
set_property(TARGET ReforgeShaper::solver APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ReforgeShaper::solver PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_solver.so"
  IMPORTED_SONAME_RELEASE "libreforge_shaper_solver.so"
  )

list(APPEND _cmake_import_check_targets ReforgeShaper::solver )
list(APPEND _cmake_import_check_files_for_ReforgeShaper::solver "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_solver.so" )

# Import target "ReforgeShaper::backend" for configuration "Release"
set_property(TARGET ReforgeShaper::backend APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ReforgeShaper::backend PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_backend.so"
  IMPORTED_SONAME_RELEASE "libreforge_shaper_backend.so"
  )

list(APPEND _cmake_import_check_targets ReforgeShaper::backend )
list(APPEND _cmake_import_check_files_for_ReforgeShaper::backend "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_shaper_backend.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
