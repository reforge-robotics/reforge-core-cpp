#pragma once

#include <cstddef>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"
#include "reforge_core/util/timing/joint_limits.hpp"
#include "reforge_core/util/timing/joint_trajectory.hpp"

namespace reforge::control::shaper {

/** Own one sampled state-space cascade for a set of damped modes. */
struct REFORGE_SHAPER_EXPORT DiscreteModalCascade final {
    reforge::native::Matrix modes_rad_s;
    double sample_period_s = 0.0;
    reforge::native::Matrix a_matrix;
    reforge::native::Matrix b_matrix;
    reforge::native::Matrix c_matrix;
    reforge::native::Matrix d_matrix;
};

/** Report explicit-modal sparse-QP size, timing, and validation. */
struct REFORGE_SHAPER_EXPORT ExplicitModalSwitchQpReport final {
    std::string status;
    std::optional<double> objective_value;
    double assembly_time_s = 0.0;
    double conic_conversion_time_s = 0.0;
    double solve_time_s = 0.0;
    double solver_setup_time_s = 0.0;
    double solver_iteration_time_s = 0.0;
    bool solver_cache_hit = false;
    double solver_update_time_s = 0.0;
    std::size_t solver_cache_hits = 0;
    std::size_t solver_cache_misses = 0;
    std::size_t solver_cache_entry_count = 0;
    std::size_t solver_cache_estimated_bytes = 0;
    std::size_t variable_count = 0;
    std::size_t constraint_count = 0;
    std::size_t quadratic_nonzeros = 0;
    std::size_t constraint_nonzeros = 0;
    std::size_t matrix_storage_bytes = 0;
    double max_constraint_violation = 0.0;
    double max_modal_dynamics_residual = 0.0;
    double max_terminal_residual_bound_violation_rad = 0.0;
};

/** Own a native-grid explicit-modal switch result. */
struct REFORGE_SHAPER_EXPORT ExplicitModalSwitchOptimizationResult final {
    reforge::util::timing::JointTrajectory trajectory;
    std::map<std::size_t, reforge::native::Matrix> modal_states_by_axis;
    std::map<std::size_t, reforge::native::Matrix>
        modal_response_by_axis_rad;
    std::map<std::size_t, reforge::native::Matrix>
        terminal_residual_by_axis_rad;
    std::map<std::size_t, double> terminal_rms_residual_by_axis_rad;
    std::map<std::size_t, double> terminal_peak_residual_by_axis_rad;
    double normalized_terminal_residual_energy = 0.0;
    double max_terminal_residual_rad = 0.0;
    double average_terminal_residual_rad = 0.0;
    ExplicitModalSwitchQpReport report;
};

/** Own a reconstructed native-rate result and its coarse QP evidence. */
struct REFORGE_SHAPER_EXPORT ResampledExplicitModalSwitchOptimizationResult final {
    reforge::util::timing::JointTrajectory trajectory;
    ExplicitModalSwitchOptimizationResult coarse_result;
    std::map<std::size_t, reforge::native::Matrix>
        terminal_residual_by_axis_rad;
    std::map<std::size_t, double> terminal_rms_residual_by_axis_rad;
    std::map<std::size_t, double> terminal_peak_residual_by_axis_rad;
    double normalized_terminal_residual_energy = 0.0;
    double max_terminal_residual_rad = 0.0;
    double average_terminal_residual_rad = 0.0;
    double requested_optimization_frequency_hz = 0.0;
    double optimization_frequency_hz = 0.0;
    double preparation_time_s = 0.0;
    double reconstruction_and_validation_time_s = 0.0;
    double total_time_s = 0.0;
    double max_position_limit_violation_rad = 0.0;
    double max_velocity_limit_violation_rad_s = 0.0;
    double max_acceleration_limit_violation_rad_s2 = 0.0;
    double max_jerk_limit_violation_rad_s3 = 0.0;
    std::optional<std::vector<double>>
        continuous_jerk_limit_margin_rad_s3;
    double max_terminal_residual_bound_violation_rad = 0.0;

    /** Return whether every native and continuous constraint is satisfied. */
    [[nodiscard]] bool NativeConstraintsSatisfied() const noexcept;
};

/** Own complete inputs for an explicit-modal switch solve. */
struct REFORGE_SHAPER_EXPORT ExplicitModalSwitchRequest final {
    reforge::util::timing::JointTrajectory native_reference;
    reforge::util::timing::JointTrajectory command_history;
    std::optional<reforge::util::timing::JointTrajectory> fixed_tail;
    reforge::util::timing::JointStateLimits limits;
    std::map<std::size_t, reforge::native::Matrix> modes_rad_s_by_axis;
    double terminal_horizon_s = 0.0;
    double modal_objective_weight = 0.0;
    double acceleration_weight = 1.0;
    double jerk_weight = 0.01;
    double tracking_weight = 0.0;
    std::optional<std::vector<double>> max_terminal_residual_rad;
    bool condense_fixed_propagation = false;
};

/** Reuse cascade, sparse assembly, reconstruction, and validation scratch. */
class REFORGE_SHAPER_EXPORT ModalSwitchWorkspace final {
public:
    /** Construct an empty reusable workspace. */
    ModalSwitchWorkspace();
    ~ModalSwitchWorkspace();
    ModalSwitchWorkspace(ModalSwitchWorkspace&&) noexcept;
    ModalSwitchWorkspace& operator=(ModalSwitchWorkspace&&) noexcept;
    ModalSwitchWorkspace(const ModalSwitchWorkspace&) = delete;
    ModalSwitchWorkspace& operator=(const ModalSwitchWorkspace&) = delete;

private:
    friend struct ModalSwitchWorkspaceAccess;

    class Impl;
    std::unique_ptr<Impl> impl_;
};

/** Build the sampled cascade for modal rows `[wn rad/s, zeta]`. */
[[nodiscard]] REFORGE_SHAPER_EXPORT DiscreteModalCascade
BuildDiscreteModalCascade(
    const reforge::native::Matrix& modes_rad_s, double sample_period_s);

/** Return the steady state for a constant command [rad]. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Vector
SteadyStateModalCascadeState(
    const DiscreteModalCascade& cascade, double command_rad);

/** Reconstruct cascade state after an ordered command history [rad]. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Vector
ModalCascadeStateFromCommandHistory(
    const DiscreteModalCascade& cascade,
    const reforge::native::Vector& command_history_rad);

/** Predict sampled modal response for commands and an initial state. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Vector
PredictModalCascadeResponse(
    const DiscreteModalCascade& cascade,
    const reforge::native::Vector& command_rad,
    const reforge::native::Vector& initial_state);

/** Solve the explicit-modal QP on its supplied native grid. */
[[nodiscard]] REFORGE_SHAPER_EXPORT ExplicitModalSwitchOptimizationResult
SolveExplicitModalSwitchTrajectory(
    const ExplicitModalSwitchRequest& request,
    ModalSwitchWorkspace* workspace = nullptr);

/** Solve on a target grid and reconstruct onto the native input grid. */
[[nodiscard]] REFORGE_SHAPER_EXPORT
ResampledExplicitModalSwitchOptimizationResult
SolveResampledExplicitModalSwitchTrajectory(
    const ExplicitModalSwitchRequest& request,
    double optimization_frequency_hz,
    ModalSwitchWorkspace* workspace = nullptr);

}  // namespace reforge::control::shaper
