#pragma once

#include <cstddef>
#include <memory>
#include <optional>
#include <vector>

#include "reforge_core/control/shaper/config.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"
#include "reforge_core/util/timing/joint_trajectory.hpp"

namespace reforge::control::shaper {

/** Select the joint columns used for residual path geometry. */
enum class ResidualPathScope {
    kShapedAxes,
    kAllJoints,
};

/** Identify the attach point and permitted transition/search range. */
struct REFORGE_SHAPER_EXPORT ResidualAlignmentTarget final {
    std::size_t target_index = 0;
    std::size_t transition_start_index = 0;
    std::size_t switch_earliest_start_index = 0;
};

/** Own complete global metadata for windowed residual alignment. */
struct REFORGE_SHAPER_EXPORT ResidualAlignmentPlan final {
    reforge::native::Matrix raw_positions_rad;
    reforge::native::Matrix raw_velocities_rad_s;
    reforge::native::Matrix raw_accelerations_rad_s2;
    reforge::native::Vector time_s;
    reforge::native::Vector raw_path_rad;
    reforge::native::Vector weight_profile;
    std::size_t transition_start_index = 0;
    std::size_t target_index = 0;
    double shaping_weight = 0.0;
    std::optional<ResidualSwitchLimits> residual_switch_limits;
    std::size_t switch_earliest_start_index = 0;
    std::vector<reforge::native::Matrix> modal_params_by_axis;
};

/** Return shaped-path advance at the raw attach coordinate, if reached. */
[[nodiscard]] REFORGE_SHAPER_EXPORT std::optional<double>
FindAlignmentAdvance(
    const reforge::native::Vector& raw_path_rad,
    const reforge::native::Vector& shaped_path_rad,
    const reforge::native::Vector& shaped_time_s,
    const reforge::native::Vector& raw_time_s,
    std::size_t transition_start_index);

/** Detect, plan, and reconstruct residual-only path alignment. */
class REFORGE_SHAPER_EXPORT ResidualAlignmentOrchestrator final {
public:
    /** Construct alignment ownership for fixed controller dimensions. */
    ResidualAlignmentOrchestrator(
        double sample_time_s,
        std::size_t num_axes,
        std::size_t num_joints,
        ResidualPathScope residual_path_scope,
        bool require_zero_acceleration_region);
    ~ResidualAlignmentOrchestrator();
    ResidualAlignmentOrchestrator(ResidualAlignmentOrchestrator&&) noexcept;
    ResidualAlignmentOrchestrator& operator=(
        ResidualAlignmentOrchestrator&&) noexcept;
    ResidualAlignmentOrchestrator(const ResidualAlignmentOrchestrator&) =
        delete;
    ResidualAlignmentOrchestrator& operator=(
        const ResidualAlignmentOrchestrator&) = delete;

    /** Detect the deterministic attach target for one path. */
    [[nodiscard]] std::optional<ResidualAlignmentTarget> DetectTarget(
        const reforge::native::Matrix& path_velocities_rad_s,
        const reforge::native::Matrix& path_accelerations_rad_s2,
        double residual_transition_margin_s,
        const std::optional<ResidualSwitchLimits>& residual_switch_limits,
        bool apply_window_target_margin) const;

    /** Build full window metadata with one fixed attach-point modal snapshot. */
    [[nodiscard]] ResidualAlignmentPlan MakeWindowPlan(
        const reforge::util::timing::JointTrajectory& raw_trajectory,
        const ResidualAlignmentTarget& target,
        double shaping_weight,
        const std::optional<ResidualSwitchLimits>& residual_switch_limits,
        std::vector<reforge::native::Matrix> modal_params_by_axis) const;

    /** Project joint samples to the configured residual path coordinate. */
    [[nodiscard]] reforge::native::Matrix PathValues(
        const reforge::native::Matrix& values) const;

    /** Construct the smooth raw-to-shaped residual weight profile. */
    [[nodiscard]] reforge::native::Vector WeightProfile(
        std::size_t samples,
        std::size_t target_index,
        std::size_t transition_start_index,
        double shaping_weight) const;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace reforge::control::shaper
