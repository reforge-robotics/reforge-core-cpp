#pragma once

#include <cstddef>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <Eigen/SparseCore>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"
#include "reforge_core/util/timing/joint_limits.hpp"
#include "reforge_core/util/timing/joint_trajectory.hpp"

namespace reforge::util::trajopt {

/** Own one additional quadratic joint-position objective. */
struct REFORGE_SHAPER_EXPORT TrajectoryQpPositionCost final {
    Eigen::SparseMatrix<double, Eigen::ColMajor> quadratic_matrix;
    reforge::native::Vector linear_vector;
    double constant_term = 0.0;
    std::string name;
};

/** Report solver, problem-size, and post-solve validation results. */
struct REFORGE_SHAPER_EXPORT TrajOptReport final {
    std::string status;
    std::string solver_name;
    bool is_optimal = false;
    bool is_optimal_inaccurate = false;
    std::optional<double> objective_value;
    double solve_call_time_s = 0.0;
    std::optional<double> setup_time_s;
    std::optional<double> solve_time_s;
    std::optional<std::size_t> iteration_count;
    bool solver_cache_hit = false;
    double solver_update_time_s = 0.0;
    std::size_t solver_cache_hits = 0;
    std::size_t solver_cache_misses = 0;
    std::size_t solver_cache_entry_count = 0;
    std::size_t solver_cache_estimated_bytes = 0;
    std::size_t sample_count = 0;
    std::size_t dof = 0;
    double sample_period_s = 0.0;
    double acceleration_weight = 1.0;
    double jerk_weight = 0.01;
    double tracking_weight = 0.0;
    bool feasible_only = false;
    double max_constraint_violation = 0.0;
    double l2_constraint_violation = 0.0;
    bool all_constraints_satisfied = false;
    double max_position_limit_violation_rad = 0.0;
    double max_velocity_limit_violation_rad_s = 0.0;
    double max_acceleration_limit_violation_rad_s2 = 0.0;
    double max_jerk_limit_violation_rad_s3 = 0.0;
    double max_position_dynamics_residual_rad = 0.0;
    double max_velocity_dynamics_residual_rad_s = 0.0;
    double max_boundary_residual = 0.0;
    std::vector<std::string> additional_position_cost_names;
};

/** Own trajectory-QP inputs and their omission semantics. */
struct REFORGE_SHAPER_EXPORT TrajectoryQpRequest final {
    reforge::util::timing::JointStateLimits limits;
    std::optional<reforge::native::Vector> initial_position_rad;
    std::optional<reforge::native::Vector> initial_velocity_rad_s;
    std::optional<reforge::native::Vector> initial_acceleration_rad_s2;
    std::optional<reforge::native::Vector> final_position_rad;
    std::optional<reforge::native::Vector> final_velocity_rad_s;
    std::optional<reforge::native::Vector> final_acceleration_rad_s2;
    std::optional<std::size_t> sample_count;
    std::optional<double> sample_period_s;
    double acceleration_weight = 1.0;
    double jerk_weight = 0.01;
    double tracking_weight = 0.0;
    bool feasible_only = false;
    std::optional<reforge::util::timing::JointTrajectory> reference;
    std::vector<TrajectoryQpPositionCost> additional_position_costs;
};

/** Reuse deterministic sparse trajectory-QP assembly and solver scratch. */
class REFORGE_SHAPER_EXPORT TrajectoryQpWorkspace final {
public:
    /** Construct an empty reusable workspace. */
    TrajectoryQpWorkspace();
    ~TrajectoryQpWorkspace();
    TrajectoryQpWorkspace(TrajectoryQpWorkspace&&) noexcept;
    TrajectoryQpWorkspace& operator=(TrajectoryQpWorkspace&&) noexcept;
    TrajectoryQpWorkspace(const TrajectoryQpWorkspace&) = delete;
    TrajectoryQpWorkspace& operator=(const TrajectoryQpWorkspace&) = delete;

private:
    friend std::pair<reforge::util::timing::JointTrajectory, TrajOptReport>
    PlanTrajectoryQp(
        const TrajectoryQpRequest& request,
        TrajectoryQpWorkspace* workspace);

    class Impl;
    std::unique_ptr<Impl> impl_;
};

/** Plan one constrained sampled joint trajectory.
 *
 * Args:
 *     request: Owned limits, boundaries, grid, weights, and optional costs.
 *     workspace: Optional caller-owned reusable sparse/solver workspace.
 *
 * Returns:
 *     Owned trajectory and normalized report.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT
std::pair<reforge::util::timing::JointTrajectory, TrajOptReport>
PlanTrajectoryQp(
    const TrajectoryQpRequest& request,
    TrajectoryQpWorkspace* workspace = nullptr);

}  // namespace reforge::util::trajopt
