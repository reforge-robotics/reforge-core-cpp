#pragma once

#include "reforge_core/native/common/export.hpp"

namespace reforge::util {

/** Evaluate a clamped quintic transition with flat endpoint derivatives.
 *
 * Args:
 *     unit_progress: Normalized transition progress [unitless].
 *
 * Returns:
 *     Smoothed progress in `[0.0, 1.0]`.
 *
 * Raises:
 *     reforge::native::InvalidArgumentError: If `unit_progress` is not finite.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT double Smootherstep(double unit_progress);

}  // namespace reforge::util
