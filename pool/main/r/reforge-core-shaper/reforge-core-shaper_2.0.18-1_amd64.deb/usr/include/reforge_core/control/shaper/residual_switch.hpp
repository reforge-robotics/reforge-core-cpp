#pragma once

#include <cstddef>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "reforge_core/control/shaper/config.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"
#include "reforge_core/util/timing/joint_limits.hpp"
#include "reforge_core/util/timing/joint_trajectory.hpp"

namespace reforge::control::shaper {

/** Identify the optimizer that produced a residual-switch candidate. */
enum class ResidualSwitchCandidateSource {
    kCommandSpace,
    kModalAware,
};

/** Store smoothness, timing, limit, and residual evidence for one candidate. */
struct REFORGE_SHAPER_EXPORT ResidualSwitchCandidateDiagnostics final {
    std::size_t duration_samples = 0;
    std::size_t switch_start_index = 0;
    std::vector<double> peak_jerk_rad_s3;
    std::vector<double> switch_start_acceleration_jump_rad_s2;
    std::vector<double> attach_acceleration_jump_rad_s2;
    std::optional<std::vector<double>> acceleration_limit_margin_rad_s2;
    std::optional<std::vector<double>> velocity_limit_margin_rad_s;
    std::optional<double> extra_duration_fraction;
    std::optional<double> normalized_terminal_residual_energy;
    std::optional<std::map<std::size_t, double>>
        terminal_rms_residual_by_axis_rad;
    std::optional<std::map<std::size_t, double>>
        terminal_peak_residual_by_axis_rad;
    std::optional<std::string> smoothness_rejection_reason;
    ResidualSwitchCandidateSource source =
        ResidualSwitchCandidateSource::kCommandSpace;
    std::optional<std::size_t> optimization_sample_count;
    std::optional<std::size_t> qp_variable_count;
    std::optional<std::size_t> qp_constraint_count;
    std::optional<std::size_t> qp_matrix_storage_bytes;
    std::optional<std::size_t> native_sample_count;
    std::optional<double> planning_time_s;
    std::optional<double> preparation_time_s;
    std::optional<double> assembly_time_s;
    std::optional<double> conic_conversion_time_s;
    std::optional<double> solve_time_s;
    std::optional<double> solver_setup_time_s;
    std::optional<double> solver_iteration_time_s;
    std::optional<bool> solver_cache_hit;
    std::optional<double> solver_update_time_s;
    std::optional<std::size_t> solver_cache_hits;
    std::optional<std::size_t> solver_cache_misses;
    std::optional<std::size_t> solver_cache_entry_count;
    std::optional<std::size_t> solver_cache_estimated_bytes;
    std::optional<double> reconstruction_and_validation_time_s;
    std::optional<std::vector<double>> position_limit_margin_rad;
    std::optional<std::vector<double>> jerk_limit_margin_rad_s3;
    std::optional<std::vector<double>>
        continuous_jerk_limit_margin_rad_s3;
};

/** Summarize bounded candidate search and its selected candidate.
 *
 * Window timing fields report post-solve qualification of synchronous work.
 * They do not imply that solver execution was interrupted or deterministically
 * bounded by the emission deadline.
 */
struct REFORGE_SHAPER_EXPORT ResidualSwitchSearchDiagnostics final {
    std::size_t attempts = 0;
    std::size_t seed_duration_samples = 0;
    std::optional<ResidualSwitchCandidateDiagnostics> selected_candidate;
    std::vector<ResidualSwitchCandidateDiagnostics> candidates;
    std::vector<std::string> fallback_reasons;
    std::vector<std::size_t> attempted_duration_samples;
    std::vector<std::string> attempt_outcomes;
    std::optional<double> window_solve_time_s;
    std::optional<double> window_deadline_s;
    std::optional<double> window_deadline_margin_s;
    std::optional<bool> window_timing_qualified;
};

/** Own one residual-switch search request. */
struct REFORGE_SHAPER_EXPORT ResidualSwitchRequest final {
    reforge::util::timing::JointTrajectory raw_trajectory;
    reforge::util::timing::JointTrajectory shaped_trajectory;
    std::size_t attach_index = 0;
    std::size_t latest_start_index = 0;
    std::size_t earliest_start_index = 0;
    double advance_s = 0.0;
    double shaping_weight = 0.0;
    reforge::util::timing::JointStateLimits state_limits;
    std::size_t search_resolution_samples = 1;
    std::size_t max_qp_attempts = 1;
    double tracking_weight = 0.0;
    double acceleration_weight = 1.0;
    double jerk_weight = 0.01;
    std::optional<double> max_extra_duration_fraction;
    std::optional<double> raw_command_duration_s;
    std::optional<std::size_t> output_stop_index;
    std::vector<reforge::native::Matrix> modal_params_by_axis;
    std::optional<ResidualSwitchModalConfig> modal_config;
    std::optional<std::size_t> initial_duration_samples;
    ResidualSwitchSearchPolicy search_policy =
        kDefaultResidualSwitchSearchPolicy;
};

/** Own one solved switch segment and its source start index. */
struct REFORGE_SHAPER_EXPORT ResidualSwitchSolution final {
    std::size_t start_index = 0;
    reforge::util::timing::JointTrajectory trajectory;
};

/** Own one selected solution and complete search diagnostics. */
struct REFORGE_SHAPER_EXPORT ResidualSwitchPlanResult final {
    ResidualSwitchSolution solution;
    ResidualSwitchSearchDiagnostics diagnostics;
};

/** Plan deterministic constrained residual switches and own latest diagnostics. */
class REFORGE_SHAPER_EXPORT ResidualSwitchPlanner final {
public:
    /** Construct a planner for one positive native sample period [s]. */
    explicit ResidualSwitchPlanner(double sample_time_s);
    ~ResidualSwitchPlanner();
    ResidualSwitchPlanner(ResidualSwitchPlanner&&) noexcept;
    ResidualSwitchPlanner& operator=(ResidualSwitchPlanner&&) noexcept;
    ResidualSwitchPlanner(const ResidualSwitchPlanner&) = delete;
    ResidualSwitchPlanner& operator=(const ResidualSwitchPlanner&) = delete;

    /** Clear latest diagnostics without changing immutable configuration. */
    void Reset();

    /** Search for and select one constrained switch. */
    [[nodiscard]] ResidualSwitchPlanResult Plan(
        const ResidualSwitchRequest& request);

    /** Return the latest completed search diagnostics, if any. */
    [[nodiscard]] const std::optional<ResidualSwitchSearchDiagnostics>&
    latest_diagnostics() const noexcept;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace reforge::control::shaper
