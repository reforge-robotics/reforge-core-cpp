#pragma once

#include <cstddef>
#include <optional>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::util::timing {

/** Store sampled joint kinematics with lazy derivative caches. */
class REFORGE_SHAPER_EXPORT JointTrajectory final {
public:
    /** Construct a validated joint trajectory.
     *
     * Args:
     *     positions: Joint positions `[samples, joints]` [rad].
     *     velocities: Optional velocities on the same grid [rad/s].
     *     accelerations: Optional accelerations on the same grid [rad/s²].
     *     time: Optional strictly increasing timestamps [s].
     *     dt_s: Optional positive uniform spacing used when `time` is absent.
     *     jerks: Optional jerks on the same grid [rad/s³].
     *
     * Raises:
     *     reforge::native::InvalidArgumentError: If samples, caches, or timing
     *         are invalid.
     */
    JointTrajectory(
        reforge::native::Matrix positions,
        std::optional<reforge::native::Matrix> velocities = std::nullopt,
        std::optional<reforge::native::Matrix> accelerations = std::nullopt,
        std::optional<reforge::native::Vector> time = std::nullopt,
        std::optional<double> dt_s = std::nullopt,
        std::optional<reforge::native::Matrix> jerks = std::nullopt);

    /** Return owned joint positions `[samples, joints]` [rad]. */
    [[nodiscard]] const reforge::native::Matrix& positions() const noexcept {
        return positions_;
    }

    /** Return owned timestamps `[samples]` [s]. */
    [[nodiscard]] const reforge::native::Vector& time() const noexcept {
        return time_;
    }

    /** Return sample count. */
    [[nodiscard]] std::size_t sample_count() const noexcept {
        return static_cast<std::size_t>(positions_.rows());
    }

    /** Return joint count. */
    [[nodiscard]] std::size_t dof() const noexcept {
        return static_cast<std::size_t>(positions_.cols());
    }

    /** Return velocities, calculating and caching them when absent [rad/s]. */
    [[nodiscard]] const reforge::native::Matrix& velocities() const;

    /** Return accelerations, calculating and caching them when absent [rad/s²]. */
    [[nodiscard]] const reforge::native::Matrix& accelerations() const;

    /** Return jerks, calculating and caching them when absent [rad/s³]. */
    [[nodiscard]] const reforge::native::Matrix& jerks() const;

    /** Return a detached copy preserving populated derivative caches. */
    [[nodiscard]] JointTrajectory Copy() const;

    /** Report whether a velocity cache is currently populated. */
    [[nodiscard]] bool has_velocity_cache() const noexcept {
        return velocities_.has_value();
    }

    /** Report whether an acceleration cache is currently populated. */
    [[nodiscard]] bool has_acceleration_cache() const noexcept {
        return accelerations_.has_value();
    }

    /** Report whether a jerk cache is currently populated. */
    [[nodiscard]] bool has_jerk_cache() const noexcept {
        return jerks_.has_value();
    }

private:
    reforge::native::Matrix positions_;
    reforge::native::Vector time_;
    mutable std::optional<reforge::native::Matrix> velocities_;
    mutable std::optional<reforge::native::Matrix> accelerations_;
    mutable std::optional<reforge::native::Matrix> jerks_;
};

/** Return interval first differences as a sample-aligned derivative cache.
 *
 * Args:
 *     signal_values: Sample-major signal matrix.
 *     sample_spacing_s: Uniform positive spacing [s].
 *
 * Returns:
 *     Derivative matrix with the same shape as `signal_values`.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Matrix
SampleAlignedFirstDifference(
    const reforge::native::Matrix& signal_values, double sample_spacing_s);

/** Return interval first differences on explicit sample coordinates.
 *
 * Args:
 *     signal_values: Sample-major signal matrix.
 *     sample_times_s: Strictly increasing sample coordinates [s].
 *
 * Returns:
 *     Derivative matrix with the same shape as `signal_values`.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Matrix
SampleAlignedFirstDifference(
    const reforge::native::Matrix& signal_values,
    const reforge::native::Vector& sample_times_s);

}  // namespace reforge::util::timing
