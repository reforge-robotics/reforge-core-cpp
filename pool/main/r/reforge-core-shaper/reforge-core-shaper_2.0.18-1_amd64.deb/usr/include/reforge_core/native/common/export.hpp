#pragma once

#if defined(_WIN32) && !defined(REFORGE_SHAPER_STATIC_DEFINE)
#  if defined(REFORGE_SHAPER_COMMON_EXPORTS)
#    define REFORGE_SHAPER_EXPORT __declspec(dllexport)
#  else
#    define REFORGE_SHAPER_EXPORT __declspec(dllimport)
#  endif
#else
#  define REFORGE_SHAPER_EXPORT
#endif
