#pragma once

#include <variant>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::shaper {

inline constexpr double kDefaultWindowApplyFraction = 0.90;
inline constexpr int kMinDerivativeLookaheadSamples = 2;
inline constexpr double kMinVibrationShapingWeight = 0.0;
inline constexpr double kMaxVibrationShapingWeight = 1.0;
inline constexpr double kPathCoordinateCompareAtolRad = 1.0e-12;
inline constexpr double kTimeCompareAtolS = 1.0e-12;

using ShapingWeight =
    std::variant<double, reforge::native::Vector>;

/** Validate a scalar raw-to-shaped blend weight. */
[[nodiscard]] REFORGE_SHAPER_EXPORT double ValidateVibrationShapingWeight(
    double weight);

/** Validate a nonnegative vibration-weight transition duration [s]. */
[[nodiscard]] REFORGE_SHAPER_EXPORT double ValidateVibrationWeightTransitionS(
    double transition_s);

/** Validate a positive vibration-weight transition rate [1/s]. */
[[nodiscard]] REFORGE_SHAPER_EXPORT double ValidateVibrationWeightRatePerS(
    double rate_per_s);

/** Blend sample-major raw and shaped matrices with scalar or sample weights. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Matrix BlendArrays(
    const reforge::native::Matrix& raw,
    const reforge::native::Matrix& shaped,
    const ShapingWeight& shaping_weight);

/** Blend a shaped tail against a held raw joint endpoint. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::ShapedTrajectory
BlendTailWithHeldRawEndpoint(
    const reforge::native::Vector& raw_position,
    const reforge::native::ShapedTrajectory& shaped_tail,
    double shaping_weight);

/** Compute cumulative Euclidean joint-space path length [rad]. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Vector
JointPathCoordinate(const reforge::native::Matrix& positions);

}  // namespace reforge::control::shaper
