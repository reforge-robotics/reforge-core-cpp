#pragma once

#include <string_view>

#include "reforge_core/native/common/export.hpp"

namespace reforge::control::model {

/** Enumerate persisted control-model bundle types used in manifests. */
enum class ModelType {
    kJointController,
    kShaper,
};

/** Return the exact persisted value for a control-model bundle type.
 *
 * Args:
 *     model_type: Native control-model bundle type.
 *
 * Returns:
 *     Exact model-type identifier stored in manifests.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT std::string_view ToString(
    ModelType model_type) noexcept;

/** Parse an exact persisted control-model bundle type.
 *
 * Args:
 *     value: Exact model-type identifier stored in manifests.
 *
 * Returns:
 *     Parsed native model type.
 *
 * Raises:
 *     InvalidArgumentError: If `value` is not a supported model type.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT ModelType ParseModelType(
    std::string_view value);

}  // namespace reforge::control::model
