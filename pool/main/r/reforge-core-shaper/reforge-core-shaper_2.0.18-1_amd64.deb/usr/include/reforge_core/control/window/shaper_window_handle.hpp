#pragma once

#include <cstddef>
#include <optional>

#include "reforge_core/control/python/windowed_buffer.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::window {

/** Own one shaped task-space trajectory and its paired joint trajectory. */
struct REFORGE_SHAPER_EXPORT TaskSpaceShapedTrajectory final {
    reforge::native::Matrix positions_m;
    std::optional<reforge::native::Matrix> orientations_xyzw;
    reforge::native::Matrix velocities_m_s;
    reforge::native::Matrix accelerations_m_s2;
    reforge::native::Matrix joint_positions_rad;
    reforge::native::Matrix joint_velocities_rad_s;
    reforge::native::Matrix joint_accelerations_rad_s2;
    reforge::native::Vector time_s;
};

/** Own one shaped task-space output window. */
struct REFORGE_SHAPER_EXPORT TaskSpaceShapedWindow final {
    TaskSpaceShapedTrajectory trajectory;
    std::size_t start_index = 0;
    std::size_t stop_index = 0;
    bool is_tail = false;
    double compute_time_s = 0.0;
};

/** Validate one complete shaped task-space trajectory. */
REFORGE_SHAPER_EXPORT void
ValidateTaskSpaceShapedTrajectory(const TaskSpaceShapedTrajectory& trajectory);

/** Validate one shaped task-space window and its source range. */
REFORGE_SHAPER_EXPORT void
ValidateTaskSpaceShapedWindow(const TaskSpaceShapedWindow& window);

/** Define the Phase 6C lifecycle surface for joint-trajectory windows. */
class REFORGE_SHAPER_EXPORT TrajectoryWindowHandle {
  public:
    virtual ~TrajectoryWindowHandle() = default;

    /** Produce the configured startup window count. */
    [[nodiscard]] virtual std::size_t Prefill() = 0;

    /** Produce up to the requested count, or all remaining windows. */
    [[nodiscard]] virtual std::size_t
    FillAvailable(std::optional<std::size_t> max_windows = std::nullopt) = 0;

    /** Pop one ready shaped window. */
    [[nodiscard]] virtual std::optional<ShapedTrajectoryWindow>
    PopWindow() = 0;

    /** Return whether ready, source, residual, or tail work remains. */
    [[nodiscard]] virtual bool HasNext() const = 0;

    /** Produce one bounded tail window when available. */
    [[nodiscard]] virtual std::optional<ShapedTrajectoryWindow>
    FinalizeTail() = 0;

    /** Release owned runtime state exactly once. */
    virtual void Close() noexcept = 0;
};

/** Define the Phase 6C lifecycle surface for task-space windows. */
class REFORGE_SHAPER_EXPORT TaskSpaceWindowHandle {
  public:
    virtual ~TaskSpaceWindowHandle() = default;

    /** Move up to the requested startup count into the ready queue. */
    [[nodiscard]] virtual std::size_t Prefill(std::size_t prefill_windows) = 0;

    /** Move up to the requested count, or all remaining windows, to ready. */
    [[nodiscard]] virtual std::size_t
    FillAvailable(std::optional<std::size_t> max_windows = std::nullopt) = 0;

    /** Pop one ready task-space window. */
    [[nodiscard]] virtual std::optional<TaskSpaceShapedWindow> PopWindow() = 0;

    /** Return whether ready or pending task-space windows remain. */
    [[nodiscard]] virtual bool HasNext() const = 0;

    /** Release owned task-space window state exactly once. */
    virtual void Close() noexcept = 0;
};

/** Adapt one lifecycle-owned shaper handle to generic async production. */
class REFORGE_SHAPER_EXPORT ShaperWindowProducer final
    : public WindowProducerSession {
  public:
    /** Construct the producer around one fresh native trajectory handle. */
    explicit ShaperWindowProducer(
        std::unique_ptr<TrajectoryWindowHandle> handle);
    ~ShaperWindowProducer() override;
    ShaperWindowProducer(ShaperWindowProducer&&) noexcept;
    ShaperWindowProducer& operator=(ShaperWindowProducer&&) noexcept;
    ShaperWindowProducer(const ShaperWindowProducer&) = delete;
    ShaperWindowProducer& operator=(const ShaperWindowProducer&) = delete;

    /** Run the handle's configured startup prefill exactly once. */
    void PrepareSession() override;

    /** Pop or produce the next shaped trajectory payload. */
    [[nodiscard]] std::optional<WindowPayload> ProduceNext() override;

    /** Return whether the wrapped handle is fully drained. */
    [[nodiscard]] bool IsExhausted() const override;

    /** Close the handle because it owns all tail production. */
    [[nodiscard]] std::optional<WindowPayload> Finalize() override;

  private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace reforge::control::window
