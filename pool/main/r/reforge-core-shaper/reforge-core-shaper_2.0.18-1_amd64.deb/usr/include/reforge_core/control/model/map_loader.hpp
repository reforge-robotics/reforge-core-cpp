#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "reforge_core/control/model/model_types.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::model {

inline constexpr std::string_view kModelBundleFilename = "model_bundle.json";
inline constexpr std::string_view kJointControllerArtifactFilename =
    "joint_controller_models.json";
inline constexpr ModelType kJointControllerModelType =
    ModelType::kJointController;
inline constexpr std::string_view kNativeShaperArtifactFilename =
    "shaper_models.native.json";
inline constexpr std::string_view kShaperFeatureBasePrefix = "j";
inline constexpr std::string_view kShaperFeatureBaseSuffix = "_rad";
inline constexpr std::int64_t kNativeShaperArtifactVersion = 1;

/** Describe the ordered runtime feature contract for shaper inference. */
struct REFORGE_SHAPER_EXPORT ShaperRuntimeFeatureSchema final {
    std::vector<std::string> feature_names;
    std::vector<std::string> feature_units;
    std::int64_t input_feature_count = 0;
    std::int64_t base_joint_count = 0;
    std::vector<double> base_joint_reference_angles;
    std::int64_t calibration_schema_version = 1;

    /** Return whether this is the legacy `[v_deg, r_mm, inertia]` schema. */
    [[nodiscard]] bool is_legacy() const noexcept;

    /** Return the backward-compatible legacy feature schema. */
    [[nodiscard]] static ShaperRuntimeFeatureSchema Legacy();
};

/** Load shaper feature metadata, falling back to the legacy schema when absent.
 *
 * Args:
 *     directory: Model-bundle directory.
 *
 * Returns:
 *     Validated runtime feature schema with owned metadata.
 *
 * Raises:
 *     ArtifactError: If an existing manifest is malformed or inconsistent.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT ShaperRuntimeFeatureSchema
LoadShaperRuntimeFeatureSchema(const std::filesystem::path& directory);

/** Store one JSON-safe complex pole. */
struct REFORGE_SHAPER_EXPORT JointControllerPole final {
    double real = 0.0;
    double imag = 0.0;
};

/** Store one persisted joint-axis transfer-function model. */
struct REFORGE_SHAPER_EXPORT JointControllerAxis final {
    std::int64_t axis = 0;
    std::int64_t selected_pose = 0;
    std::vector<double> numerator;
    std::vector<double> denominator;
    std::vector<JointControllerPole> poles;
    double natural_frequency_rad_s = 0.0;
    double natural_frequency_hz = 0.0;
    double damping_ratio = 0.0;
    double measured_frequency_min_hz = 0.0;
    double measured_frequency_max_hz = 0.0;
};

/** Store a complete persisted joint-controller model bundle. */
struct REFORGE_SHAPER_EXPORT JointControllerModel final {
    std::int64_t schema_version = 0;
    ModelType model_type = ModelType::kJointController;
    std::int64_t num_axes = 0;
    std::string output_sensor;
    std::vector<JointControllerAxis> axes;

    /** Load and validate one joint-controller model bundle.
     *
     * Args:
     *     directory: Bundle directory containing the manifest and JSON artifact.
     *
     * Returns:
     *     Fully owned joint-controller model in controller axis order.
     */
    [[nodiscard]] static JointControllerModel Load(
        const std::filesystem::path& directory);
};

/** Identify the supported body operator for native artifact version 1. */
enum class ShaperLayerKind {
    kLinearRelu,
};

/** Own one float32 dense layer and its following versioned body operator. */
struct REFORGE_SHAPER_EXPORT ShaperDenseLayer final {
    ShaperLayerKind kind = ShaperLayerKind::kLinearRelu;
    reforge::native::FloatMatrix weight;
    Eigen::VectorXf bias;
};

/** Own one float32 linear output head. */
struct REFORGE_SHAPER_EXPORT ShaperLinearHead final {
    reforge::native::FloatMatrix weight;
    Eigen::VectorXf bias;
};

/** Own one independently shaped per-axis inference network. */
class REFORGE_SHAPER_EXPORT ShaperNet final {
public:
    /** Construct a validated inference network from owned float32 parameters.
     *
     * Args:
     *     input_feature_count: Positive input width.
     *     body_layers: Ordered zero-or-more `Linear + ReLU` body layers.
     *     order_head: Positive-width order-probability head.
     *     mode_head: Positive-width modal-parameter head.
     */
    ShaperNet(
        std::int64_t input_feature_count,
        std::vector<ShaperDenseLayer> body_layers,
        ShaperLinearHead order_head,
        ShaperLinearHead mode_head);
    ~ShaperNet();
    ShaperNet(ShaperNet&&) noexcept;
    ShaperNet& operator=(ShaperNet&&) noexcept;
    ShaperNet(const ShaperNet&) = delete;
    ShaperNet& operator=(const ShaperNet&) = delete;

    /** Return the validated input feature width. */
    [[nodiscard]] std::int64_t input_feature_count() const noexcept;

    /** Return the order-head output width. */
    [[nodiscard]] std::int64_t order_feature_count() const noexcept;

    /** Return the mode-head output width. */
    [[nodiscard]] std::int64_t mode_feature_count() const noexcept;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;

    friend class ModelBundle;
};

/** Own reusable float32 activation scratch matched to one model bundle. */
class REFORGE_SHAPER_EXPORT ModelWorkspace final {
public:
    explicit ModelWorkspace(const class ModelBundle& bundle);
    ~ModelWorkspace();
    ModelWorkspace(ModelWorkspace&&) noexcept;
    ModelWorkspace& operator=(ModelWorkspace&&) noexcept;
    ModelWorkspace(const ModelWorkspace&) = delete;
    ModelWorkspace& operator=(const ModelWorkspace&) = delete;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;

    friend class ModelBundle;
};

/** Own one immutable native shaper artifact and all per-axis networks. */
class REFORGE_SHAPER_EXPORT ModelBundle final {
public:
    /** Load and transactionally validate a native shaper model artifact.
     *
     * Args:
     *     directory: Bundle directory containing `model_bundle.json`.
     *
     * Raises:
     *     NotFoundError: If a required manifest or native artifact is absent.
     *     UnsupportedError: If the artifact schema or operator is unsupported.
     *     ArtifactError: If a supported artifact is malformed.
     */
    [[nodiscard]] static ModelBundle Load(
        const std::filesystem::path& directory);

    ~ModelBundle();
    ModelBundle(ModelBundle&&) noexcept;
    ModelBundle& operator=(ModelBundle&&) noexcept;
    ModelBundle(const ModelBundle&) = delete;
    ModelBundle& operator=(const ModelBundle&) = delete;

    /** Return the number of axis models in persisted axis order. */
    [[nodiscard]] std::int64_t axis_count() const noexcept;

    /** Return the shared runtime feature schema. */
    [[nodiscard]] const ShaperRuntimeFeatureSchema& feature_schema()
        const noexcept;

    /** Infer one feature row per axis using float32 model evaluation.
     *
     * Args:
     *     features: Feature matrix `[axes, input_features]`.
     *     workspace: Model-matched caller-owned scratch.
     *
     * Returns:
     *     Owned `(orders, modes)` matrices in axis order.
     */
    [[nodiscard]] std::pair<
        reforge::native::FloatMatrix,
        reforge::native::FloatMatrix>
    InferBatch(
        const reforge::native::FloatMatrix& features,
        ModelWorkspace& workspace) const;

    /** Infer a sample sequence in sample/axis order.
     *
     * `features_by_sample` contains one `[axes, input_features]` matrix per
     * sample. The returned vectors contain one `[axes, output_features]`
     * matrix per sample.
     */
    [[nodiscard]] std::pair<
        std::vector<reforge::native::FloatMatrix>,
        std::vector<reforge::native::FloatMatrix>>
    InferSequence(
        const std::vector<reforge::native::FloatMatrix>& features_by_sample,
        ModelWorkspace& workspace) const;

private:
    class Impl;
    explicit ModelBundle(std::unique_ptr<Impl> impl);
    std::unique_ptr<Impl> impl_;

    friend class ModelWorkspace;
};

/** Dispatch a model bundle using the exact persisted model type. */
class REFORGE_SHAPER_EXPORT ModelLoader final {
public:
    enum class LoadedKind {
        kShaper,
        kJointController,
    };

    /** Return the model kind selected by `model_bundle.json`.
     *
     * Missing manifests preserve the legacy shaper-model dispatch.
     */
    [[nodiscard]] static LoadedKind Inspect(
        const std::filesystem::path& directory);

    /** Load the exact native model selected by `model_bundle.json`.
     *
     * Args:
     *     directory: Bundle directory to inspect and load.
     *
     * Returns:
     *     Immutable shaper bundle or owned joint-controller bundle.
     */
    [[nodiscard]] static std::variant<ModelBundle, JointControllerModel> Load(
        const std::filesystem::path& directory);
};

}  // namespace reforge::control::model
