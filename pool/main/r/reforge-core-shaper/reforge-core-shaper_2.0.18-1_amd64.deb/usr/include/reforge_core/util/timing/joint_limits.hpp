#pragma once

#include <cstddef>
#include <optional>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::util::timing {

/** Store immutable lower and upper limits for one joint-state quantity. */
class REFORGE_SHAPER_EXPORT JointStateBox final {
public:
    /** Convert and validate lower and upper joint-state limits.
     *
     * Args:
     *     lower: Per-joint lower limits.
     *     upper: Per-joint upper limits.
     *
     * Raises:
     *     reforge::native::InvalidArgumentError: If shapes differ, a value is
     *         non-finite, or a lower bound exceeds its upper bound.
     */
    JointStateBox(
        reforge::native::Vector lower, reforge::native::Vector upper);

    /** Return the owned lower-limit vector. */
    [[nodiscard]] const reforge::native::Vector& lower() const noexcept {
        return lower_;
    }

    /** Return the owned upper-limit vector. */
    [[nodiscard]] const reforge::native::Vector& upper() const noexcept {
        return upper_;
    }

    /** Return the number of joints described by the box. */
    [[nodiscard]] std::size_t size() const noexcept {
        return static_cast<std::size_t>(lower_.size());
    }

private:
    reforge::native::Vector lower_;
    reforge::native::Vector upper_;
};

/** Store optional position, velocity, acceleration, and jerk boxes. */
class REFORGE_SHAPER_EXPORT JointStateLimits final {
public:
    /** Construct a consistent set of optional joint-state boxes.
     *
     * Args:
     *     q: Optional joint position limits [rad].
     *     qd: Optional joint velocity limits [rad/s].
     *     qdd: Optional joint acceleration limits [rad/s^2].
     *     qddd: Optional joint jerk limits [rad/s^3].
     *
     * Raises:
     *     reforge::native::InvalidArgumentError: If supplied boxes describe
     *         different numbers of joints.
     */
    JointStateLimits(
        std::optional<JointStateBox> q = std::nullopt,
        std::optional<JointStateBox> qd = std::nullopt,
        std::optional<JointStateBox> qdd = std::nullopt,
        std::optional<JointStateBox> qddd = std::nullopt);

    /** Return optional joint position limits [rad]. */
    [[nodiscard]] const std::optional<JointStateBox>& q() const noexcept {
        return q_;
    }

    /** Return optional joint velocity limits [rad/s]. */
    [[nodiscard]] const std::optional<JointStateBox>& qd() const noexcept {
        return qd_;
    }

    /** Return optional joint acceleration limits [rad/s²]. */
    [[nodiscard]] const std::optional<JointStateBox>& qdd() const noexcept {
        return qdd_;
    }

    /** Return optional joint jerk limits [rad/s³]. */
    [[nodiscard]] const std::optional<JointStateBox>& qddd() const noexcept {
        return qddd_;
    }

private:
    std::optional<JointStateBox> q_;
    std::optional<JointStateBox> qd_;
    std::optional<JointStateBox> qdd_;
    std::optional<JointStateBox> qddd_;
};

}  // namespace reforge::util::timing
