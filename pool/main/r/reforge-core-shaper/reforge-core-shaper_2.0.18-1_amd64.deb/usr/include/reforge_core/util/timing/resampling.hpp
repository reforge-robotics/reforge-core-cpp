#pragma once

#include <string_view>

#include "reforge_core/native/common/export.hpp"
#include "reforge_core/util/timing/joint_trajectory.hpp"

namespace reforge::util::timing {

inline constexpr std::string_view kAnsiYellow = "\033[33m";
inline constexpr std::string_view kAnsiReset = "\033[0m";

/** Select how a resampled grid handles a fractional terminal interval. */
enum class ResamplingTimeGridMode {
    kExactDtAppendEndpoint,
    kExactDtTrim,
    kExactDurationAdjustDt,
    kExactDtExtendEndpoint,
};

/** Select linear or not-a-knot cubic position reconstruction. */
enum class ResamplingMethod {
    kLinear,
    kCubic,
};

/** Parse an exact public resampling grid-mode string. */
[[nodiscard]] REFORGE_SHAPER_EXPORT ResamplingTimeGridMode
ParseResamplingTimeGridMode(std::string_view value);

/** Parse an exact public resampling method string. */
[[nodiscard]] REFORGE_SHAPER_EXPORT ResamplingMethod ParseResamplingMethod(
    std::string_view value);

/** Sample a trajectory at caller-provided timestamps using linear interpolation.
 *
 * Args:
 *     trajectory: Source joint trajectory.
 *     query_time_s: Requested timestamps [s].
 *     include_derivatives: Whether to interpolate velocity and acceleration
 *         caches.
 *
 * Returns:
 *     Sampled trajectory. An empty query returns a detached copy of the input.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT JointTrajectory SampleTrajectoryAtTimes(
    const JointTrajectory& trajectory,
    const reforge::native::Vector& query_time_s,
    bool include_derivatives = true);

/** Resample a trajectory with explicit endpoint timing policy.
 *
 * Args:
 *     trajectory: Source joint trajectory.
 *     sample_time_s: Requested output spacing [s].
 *     method: Linear or cubic reconstruction method.
 *     time_grid_mode: Fractional-tail timing policy.
 *     strict: Whether cubic construction failures escape instead of falling
 *         back to linear.
 *
 * Returns:
 *     Resampled trajectory.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT JointTrajectory ResampleTrajectory(
    const JointTrajectory& trajectory,
    double sample_time_s,
    ResamplingMethod method = ResamplingMethod::kCubic,
    ResamplingTimeGridMode time_grid_mode =
        ResamplingTimeGridMode::kExactDtAppendEndpoint,
    bool strict = false);

}  // namespace reforge::util::timing
