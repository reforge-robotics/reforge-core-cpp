#pragma once

#include <optional>
#include <stdexcept>
#include <string>
#include <utility>

#include "reforge_core/native/common/export.hpp"

namespace reforge::native {

/** Identify stable native error categories across the C++ and Python APIs. */
enum class ErrorCode {
    kInvalidArgument,
    kInvalidShape,
    kOutOfRange,
    kNotFound,
    kUnsupported,
    kArtifactError,
    kSolverFailure,
    kDeadlineExceeded,
    kCancelled,
    kClosed,
    kWorkerFailure,
    kInternalError,
};

/** Carry a stable category and optional diagnostic context for native errors. */
class REFORGE_SHAPER_EXPORT Error : public std::runtime_error {
public:
    /** Construct an error with owned diagnostic context.
     *
     * Args:
     *     code: Stable error category.
     *     message: Human-readable failure description.
     *     field: Optional public field or module name.
     *     diagnostic: Optional nested diagnostic text.
     */
    Error(
        ErrorCode code,
        std::string message,
        std::optional<std::string> field = std::nullopt,
        std::optional<std::string> diagnostic = std::nullopt)
        : std::runtime_error(std::move(message)),
          code_(code),
          field_(std::move(field)),
          diagnostic_(std::move(diagnostic)) {}

    /** Return the stable error category. */
    [[nodiscard]] ErrorCode code() const noexcept { return code_; }

    /** Return the optional public field or module name. */
    [[nodiscard]] const std::optional<std::string>& field() const noexcept {
        return field_;
    }

    /** Return optional nested diagnostic text. */
    [[nodiscard]] const std::optional<std::string>& diagnostic() const noexcept {
        return diagnostic_;
    }

private:
    ErrorCode code_;
    std::optional<std::string> field_;
    std::optional<std::string> diagnostic_;
};

/** Report invalid public input values. */
class REFORGE_SHAPER_EXPORT InvalidArgumentError final : public Error {
public:
    /** Construct an invalid-argument error.
     *
     * Args:
     *     message: Human-readable failure description.
     *     field: Optional public field name.
     */
    explicit InvalidArgumentError(
        std::string message,
        std::optional<std::string> field = std::nullopt)
        : Error(
              ErrorCode::kInvalidArgument,
              std::move(message),
              std::move(field)) {}
};

/** Report an invalid public array or workspace shape. */
class REFORGE_SHAPER_EXPORT InvalidShapeError final : public Error {
public:
    /** Construct an invalid-shape error with optional field context. */
    explicit InvalidShapeError(
        std::string message,
        std::optional<std::string> field = std::nullopt,
        std::optional<std::string> diagnostic = std::nullopt)
        : Error(
              ErrorCode::kInvalidShape,
              std::move(message),
              std::move(field),
              std::move(diagnostic)) {}
};

/** Report a required file or resource that could not be found. */
class REFORGE_SHAPER_EXPORT NotFoundError final : public Error {
public:
    /** Construct a missing-resource error with optional field context. */
    explicit NotFoundError(
        std::string message,
        std::optional<std::string> field = std::nullopt,
        std::optional<std::string> diagnostic = std::nullopt)
        : Error(
              ErrorCode::kNotFound,
              std::move(message),
              std::move(field),
              std::move(diagnostic)) {}
};

/** Report a known artifact schema, operator, or capability that is unsupported. */
class REFORGE_SHAPER_EXPORT UnsupportedError final : public Error {
public:
    /** Construct an unsupported-capability error with diagnostic context. */
    explicit UnsupportedError(
        std::string message,
        std::optional<std::string> field = std::nullopt,
        std::optional<std::string> diagnostic = std::nullopt)
        : Error(
              ErrorCode::kUnsupported,
              std::move(message),
              std::move(field),
              std::move(diagnostic)) {}
};

/** Report malformed content within a supported persisted artifact. */
class REFORGE_SHAPER_EXPORT ArtifactError final : public Error {
public:
    /** Construct an artifact-validation error with JSON field context. */
    explicit ArtifactError(
        std::string message,
        std::optional<std::string> field = std::nullopt,
        std::optional<std::string> diagnostic = std::nullopt)
        : Error(
              ErrorCode::kArtifactError,
              std::move(message),
              std::move(field),
              std::move(diagnostic)) {}
};

}  // namespace reforge::native
