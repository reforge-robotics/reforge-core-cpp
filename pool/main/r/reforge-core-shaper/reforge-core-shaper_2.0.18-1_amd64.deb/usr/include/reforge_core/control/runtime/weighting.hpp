#pragma once

#include <cstddef>
#include <optional>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::runtime {

inline constexpr double kDefaultVibrationWeightRatePerS = 8.0;
inline constexpr double kMinVibrationWeightTransitionS = 0.020;
inline constexpr double kMaxVibrationWeightTransitionS = 0.250;
inline constexpr double kWeightEqualityTolerance = 1.0e-12;

/** Describe one active smootherstep weight transition. */
struct REFORGE_SHAPER_EXPORT ShapingWeightTransition final {
    double start_weight = 1.0;
    double target_weight = 1.0;
    std::size_t duration_samples = 0;
    std::size_t elapsed_samples = 0;
};

/** Own a restorable copy of vibration-weight transition state. */
struct REFORGE_SHAPER_EXPORT ShapingWeightState final {
    double current_weight = 1.0;
    double target_weight = 1.0;
    std::optional<ShapingWeightTransition> transition;
};

/** Own smootherstep blend-weight transitions for one shaping session. */
class REFORGE_SHAPER_EXPORT WeightingService final {
public:
    /** Initialize transition state.
     *
     * Args:
     *     sample_time_s: Positive controller sample period [s].
     *     initial_weight: Initial unitless blend weight in `[0, 1]`.
     */
    explicit WeightingService(
        double sample_time_s,
        double initial_weight = 1.0);

    /** Return the immutable controller sample period [s]. */
    [[nodiscard]] double sample_time_s() const noexcept;

    /** Return the most recently emitted unitless blend weight. */
    [[nodiscard]] double current_weight() const noexcept;

    /** Reset to an immediate weight and clear any transition. */
    void Reset(double weight = 1.0);

    /** Set current and target weight without a transition. */
    void SetImmediate(double weight);

    /** Return an independent restorable state snapshot. */
    [[nodiscard]] ShapingWeightState Snapshot() const;

    /** Restore a state produced by `Snapshot`. */
    void Restore(const ShapingWeightState& state);

    /** Generate and commit weights for upcoming controller samples.
     *
     * Args:
     *     samples: Number of weights to emit.
     *     target_weight: Requested unitless target weight.
     *     transition_s: Explicit duration [s], or empty for rate-derived time.
     *     rate_per_s: Positive maximum unitless change per second.
     *     max_transition_s: Nonnegative maximum derived duration [s].
     *
     * Returns:
     *     Owned per-sample unitless weights.
     */
    [[nodiscard]] reforge::native::Vector Profile(
        std::size_t samples,
        double target_weight,
        std::optional<double> transition_s,
        double rate_per_s = kDefaultVibrationWeightRatePerS,
        double max_transition_s = kMaxVibrationWeightTransitionS);

private:
    [[nodiscard]] static double WeightAtElapsed(
        const ShapingWeightTransition& transition);

    double sample_time_s_;
    double current_weight_;
    double target_weight_;
    std::optional<ShapingWeightTransition> transition_;
};

}  // namespace reforge::control::runtime
