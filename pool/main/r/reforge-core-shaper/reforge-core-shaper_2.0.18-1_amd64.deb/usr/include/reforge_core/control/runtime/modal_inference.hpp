#pragma once

#include <cstddef>
#include <functional>
#include <optional>
#include <string>
#include <string_view>
#include <tuple>
#include <vector>

#include "reforge_core/control/model/map_loader.hpp"
#include "reforge_core/control/shaper/modal_inference_strategy.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"
#include "reforge_core/util/robot_dynamics.hpp"

namespace reforge::control::runtime {

inline constexpr double kFallbackNaturalFrequencyRadPerS =
    2.0 * 3.14159265358979323846 * 5.0;
inline constexpr double kFallbackDampingRatio = 0.05;
inline constexpr double kMinValidNaturalFrequencyRadPerS = 1.0e-6;
inline constexpr double kMinValidDampingRatio = 1.0e-6;
inline constexpr double kMaxValidDampingRatio = 1.0 - 1.0e-6;
inline constexpr double kMinOperationalCombinedNaturalFrequencyRadPerS =
    2.0 * 3.14159265358979323846 * 2.0;
inline constexpr double kMinOperationalCombinedDampingRatio = 0.05;
inline constexpr double kMaxOperationalCombinedDampingRatio = 0.30;
inline constexpr double kPathSpeedCompareAtolRadPerS = 1.0e-9;
inline constexpr double kDecelerationCompareAtolRadPerS2 = 1.0e-9;
inline constexpr double kPathJerkOnsetRelativeThreshold = 0.05;

/** Select how inferred modal rows are shared between shaped axes. */
enum class SharedImpulsePolicy {
    kPerAxis,
    kAxis0,
    kMaxDelayAxis,
    kCombineAllModes,
};

/** Return the exact Python-facing shared-policy identifier. */
[[nodiscard]] REFORGE_SHAPER_EXPORT std::string_view ToString(
    SharedImpulsePolicy policy) noexcept;

/** Parse an exact Python-facing shared-policy identifier. */
[[nodiscard]] REFORGE_SHAPER_EXPORT SharedImpulsePolicy
ParseSharedImpulsePolicy(std::string_view value);

/** Store one robot state used for modal feature construction. */
struct REFORGE_SHAPER_EXPORT RobotState final {
    reforge::native::Vector joint_angles_rad;
    std::optional<reforge::native::Vector> tcp_position_m;
};

/** Store one physically valid fitted vibration mode. */
struct REFORGE_SHAPER_EXPORT FittedMode final {
    double natural_frequency_rad_per_s = 0.0;
    double damping_ratio = 0.0;
};

/** Store fitted modes for one consecutive model axis. */
struct REFORGE_SHAPER_EXPORT FittedAxisModes final {
    std::size_t axis_index = 0;
    std::vector<FittedMode> modes;
};

using AxisParams = std::vector<reforge::native::Matrix>;
using DelayEvaluator =
    std::function<std::size_t(const reforge::native::Matrix&)>;

/** Describe one stream or finite-trajectory modal selection. */
struct REFORGE_SHAPER_EXPORT ModalInferenceRequest final {
    reforge::control::shaper::ModalInferenceStrategy strategy =
        reforge::control::shaper::ModalInferenceStrategy::kFixed;
    std::vector<RobotState> states;
    std::optional<reforge::native::Matrix> command_velocity_rad_per_s;
    std::optional<reforge::native::Matrix>
        command_acceleration_rad_per_s2;
    std::optional<AxisParams> fixed_modal_params_by_axis;
    bool stream = false;
};

/** Own modal rows resolved for every source sample. */
struct REFORGE_SHAPER_EXPORT ModalInferenceResult final {
    std::vector<AxisParams> axis_params_sequence;
    std::optional<reforge::native::Matrix> order_probabilities;
    std::optional<std::size_t> snapshot_index;

    /** Return the shared fixed snapshot when every sample uses one value. */
    [[nodiscard]] std::optional<AxisParams> fixed_axis_params() const;
};

/** Own dynamics-backed feature construction using a persisted model schema. */
class REFORGE_SHAPER_EXPORT ModalFeatureService final {
public:
    /** Construct around backend-owned immutable resources and scratch.
     *
     * Args:
     *     model_directory: Resource identity used in validation diagnostics.
     *     model: Immutable native model bundle and feature schema.
     *     dynamics: Dynamics service associated with `dynamics_workspace`.
     *     dynamics_workspace: Caller-owned scratch for this service/thread.
     *     num_axes: Positive number of model-backed axes.
     *     num_joints: Positive runtime joint count.
     *     side_length_m: Polar feature side length [m].
     *     base_height_m: Polar feature base height [m].
     *     train_base_angles_rad: Legacy training base-angle prefix [rad].
     *     feature_frame_translation_m: Optional three-vector translation [m].
     */
    ModalFeatureService(
        std::string model_directory,
        const reforge::control::model::ModelBundle& model,
        const reforge::util::Dynamics& dynamics,
        reforge::util::DynamicsWorkspace& dynamics_workspace,
        std::size_t num_axes,
        std::size_t num_joints,
        double side_length_m,
        double base_height_m,
        reforge::native::Vector train_base_angles_rad,
        std::optional<reforge::native::Vector>
            feature_frame_translation_m = std::nullopt);

    /** Return configured model-backed axis count. */
    [[nodiscard]] std::size_t num_axes() const noexcept;

    /** Return configured runtime joint count. */
    [[nodiscard]] std::size_t num_joints() const noexcept;

    /** Return TCP position `[3]` [m]. */
    [[nodiscard]] reforge::native::Vector ComputeForwardKinematics(
        const reforge::native::Vector& joint_angles_rad);

    /** Return diagonal joint inertia values [kg m^2]. */
    [[nodiscard]] reforge::native::Vector ComputeInertia(
        const reforge::native::Vector& joint_angles_rad);

    /** Convert feature-frame Cartesian position to angle [rad] and radius [m]. */
    [[nodiscard]] std::pair<double, double> CartesianToPolar(
        const reforge::native::Vector& xyz_m) const;

    /** Return common polar and inertia inputs for one robot state. */
    [[nodiscard]] std::tuple<double, double, reforge::native::Vector>
    ComputeNnInputs(
        const RobotState& state,
        std::optional<reforge::native::Vector> train_base_angles_rad =
            std::nullopt);

    /** Build one float32 `[axes, features]` matrix per source sample. */
    [[nodiscard]] std::vector<reforge::native::FloatMatrix> Build(
        const std::vector<RobotState>& states);

private:
    [[nodiscard]] reforge::native::Vector TransformToTrainingFrame(
        const reforge::native::Vector& joint_angles_rad,
        const reforge::native::Vector& xyz_m,
        const reforge::native::Vector& train_base_angles_rad);
    [[nodiscard]] RobotState ReferenceBaseState(
        const RobotState& state,
        const reforge::native::Vector& reference_angles_rad) const;
    [[nodiscard]] double RuntimeFeatureValue(
        std::string_view feature_name,
        const reforge::native::Vector& active_angles_rad,
        double vertical_angle_deg,
        double radius_mm,
        double inertia) const;
    [[nodiscard]] static std::optional<std::size_t> BaseFeatureIndex(
        std::string_view feature_name);

    std::string model_directory_;
    const reforge::control::model::ShaperRuntimeFeatureSchema& schema_;
    const reforge::util::Dynamics& dynamics_;
    reforge::util::DynamicsWorkspace& dynamics_workspace_;
    std::size_t num_axes_;
    std::size_t num_joints_;
    double side_length_m_;
    double base_height_m_;
    reforge::native::Vector train_base_angles_rad_;
    std::optional<reforge::native::Vector> feature_frame_translation_m_;
};

/** Own native modal inference, fallback, snapshot, and shared-mode state. */
class REFORGE_SHAPER_EXPORT ModalInferenceService final {
public:
    /** Construct policy state without model resources for direct algorithms. */
    ModalInferenceService(
        std::size_t num_axes,
        double probability_threshold,
        SharedImpulsePolicy shared_impulse_policy);

    /** Construct complete inference around backend-owned resources. */
    ModalInferenceService(
        ModalFeatureService& feature_service,
        const reforge::control::model::ModelBundle& model,
        reforge::control::model::ModelWorkspace& model_workspace,
        std::size_t num_axes,
        double probability_threshold,
        SharedImpulsePolicy shared_impulse_policy);

    /** Clear fallback, fixed-stream, and shared-mode state. */
    void Reset();

    /** Install the delay evaluator required by `kMaxDelayAxis`. */
    void SetDelayEvaluator(DelayEvaluator evaluator);

    /** Resolve one fixed or adaptive request and commit modal latches. */
    [[nodiscard]] ModalInferenceResult Resolve(
        const ModalInferenceRequest& request);

    /** Infer fitted modes for one state. */
    [[nodiscard]] std::vector<FittedAxisModes> InferFittedModes(
        const RobotState& state);

    /** Infer fitted modes for a nonempty state sequence. */
    [[nodiscard]] std::vector<std::vector<FittedAxisModes>> InferSequence(
        const std::vector<RobotState>& states);

    /** Infer fitted modes plus second-mode probabilities. */
    [[nodiscard]] std::pair<
        std::vector<std::vector<FittedAxisModes>>,
        reforge::native::Matrix>
    InferSequenceWithOrders(const std::vector<RobotState>& states);

    /** Convert one sample of model outputs into active modal rows. */
    [[nodiscard]] AxisParams AxisParamsFromModelOutputs(
        const reforge::native::Vector& order_probabilities,
        const reforge::native::Matrix& mode_parameters);

    /** Convert fitted metadata into consecutive modal matrices. */
    [[nodiscard]] static AxisParams AxisParamsFromFittedModes(
        const std::vector<FittedAxisModes>& fitted_modes);

    /** Apply the configured per-axis or shared impulse policy. */
    [[nodiscard]] AxisParams SharedParamsForAxes(
        const AxisParams& axis_params);

    /** Return stabilized shared rows and `[axis, mode]` provenance. */
    [[nodiscard]] std::pair<
        reforge::native::Matrix,
        reforge::native::Matrix>
    SharedParamsWithSourcesForAxes(const AxisParams& axis_params);

    /** Return a copy of the most recent stabilized shared rows. */
    [[nodiscard]] std::optional<reforge::native::Matrix>
    last_valid_shared_params() const;

    /** Return whether every modal row is finite and physically valid. */
    [[nodiscard]] static bool ModalParamsAreValid(
        const reforge::native::Matrix& parameters) noexcept;

private:
    [[nodiscard]] AxisParams ValidateExplicitSnapshot(
        const AxisParams& snapshot) const;
    [[nodiscard]] static std::pair<
        reforge::native::Matrix,
        reforge::native::Matrix>
    ValidateDerivatives(const ModalInferenceRequest& request);
    [[nodiscard]] reforge::native::Matrix ConformAxisModeStructure(
        std::size_t axis,
        const reforge::native::Matrix& proposed_parameters);
    [[nodiscard]] reforge::native::Matrix ValidateAxisParams(
        std::size_t axis,
        const reforge::native::Matrix& proposed_parameters);
    [[nodiscard]] static reforge::native::Matrix BoundedInitialAxisParams(
        const reforge::native::Matrix& proposed_parameters);
    [[nodiscard]] static std::pair<
        reforge::native::Matrix,
        reforge::native::Matrix>
    CombineOperationalModes(const AxisParams& axis_params);
    [[nodiscard]] std::pair<
        reforge::native::Matrix,
        reforge::native::Matrix>
    StabilizeSharedModes(
        const reforge::native::Matrix& shared_parameters,
        const reforge::native::Matrix& shared_sources);

    ModalFeatureService* feature_service_ = nullptr;
    const reforge::control::model::ModelBundle* model_ = nullptr;
    reforge::control::model::ModelWorkspace* model_workspace_ = nullptr;
    std::size_t num_axes_;
    double probability_threshold_;
    SharedImpulsePolicy shared_impulse_policy_;
    std::optional<DelayEvaluator> delay_evaluator_;
    std::vector<std::optional<reforge::native::Matrix>>
        last_valid_axis_params_;
    std::vector<std::optional<reforge::native::Matrix>>
        active_axis_params_;
    std::vector<bool> axis_in_fallback_;
    std::vector<std::optional<std::size_t>> axis_mode_count_;
    std::optional<AxisParams> stream_fixed_axis_params_;
    std::optional<reforge::native::Matrix> last_valid_shared_params_;
    std::optional<std::size_t> shared_mode_count_latched_;
    std::optional<reforge::native::Matrix> shared_mode_params_latched_;
    std::optional<reforge::native::Matrix> shared_mode_sources_latched_;
    std::vector<bool> shared_mode_frozen_mask_;
};

}  // namespace reforge::control::runtime
