#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <utility>
#include <vector>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::runtime {

/** Return the frozen Phase 8 native base-shaper contract version. */
[[nodiscard]] REFORGE_SHAPER_EXPORT std::int64_t
BaseShaperContractVersion() noexcept;

/** Own one shaped position, velocity, and acceleration sample. */
struct REFORGE_SHAPER_EXPORT ShapedSample final {
  double position = 0.0;
  double velocity = 0.0;
  double acceleration = 0.0;
};

/** Store a scalar shaped trajectory with owned kinematics. */
struct REFORGE_SHAPER_EXPORT ShapedSignal final {
  reforge::native::Vector positions;
  reforge::native::Vector velocities;
  reforge::native::Vector accelerations;
};

/** Store a calculated ZVD impulse response and active delay. */
struct REFORGE_SHAPER_EXPORT ZvdImpulse final {
  reforge::native::Vector amplitudes;
  std::int64_t delay_samples = 0;
};

/** Report cumulative base-shaper work for one runtime session. */
struct REFORGE_SHAPER_EXPORT BaseShaperDiagnostics final {
  std::int64_t impulse_computations = 0;
  std::int64_t impulse_reuse_hits = 0;
  std::int64_t shaped_samples = 0;
  std::int64_t tail_samples = 0;
  double impulse_computation_time_s = 0.0;
  double convolution_time_s = 0.0;
  double derivative_update_time_s = 0.0;
  double tail_finalization_time_s = 0.0;
};

/** Shape one scalar command stream with a time-varying ZVD response. */
class REFORGE_SHAPER_EXPORT BaseShaper final {
public:
  /** Construct a stateful scalar shaper.
   *
   * Args:
   *     sample_time_s: Positive controller sample period [s].
   *     max_delay_samples: Optional fixed non-negative delay capacity
   *         [samples].
   */
  explicit BaseShaper(
      double sample_time_s,
      std::optional<std::int64_t> max_delay_samples = std::nullopt);
  ~BaseShaper();
  BaseShaper(BaseShaper &&) noexcept;
  BaseShaper &operator=(BaseShaper &&) noexcept;
  BaseShaper(const BaseShaper &) = delete;
  BaseShaper &operator=(const BaseShaper &) = delete;

  /** Return the immutable controller sample period [s]. */
  [[nodiscard]] double sample_time_s() const noexcept;

  /** Return the optional fixed delay capacity [samples]. */
  [[nodiscard]] std::optional<std::int64_t> max_delay_samples() const noexcept;

  /** Return the active impulse delay [samples]. */
  [[nodiscard]] std::int64_t delay_samples() const noexcept;

  /** Return an owned copy of the active impulse response. */
  [[nodiscard]] reforge::native::Vector impulse() const;

  /** Return the newest raw input when the stream has been seeded. */
  [[nodiscard]] std::optional<double> held_input() const noexcept;

  /** Return cumulative measurement-only shaping diagnostics. */
  [[nodiscard]] BaseShaperDiagnostics diagnostics() const noexcept;

  /** Shape one input sample and commit continuation state. */
  [[nodiscard]] ShapedSample
  ShapeSample(double input, const reforge::native::Matrix &modal_parameters);

  /** Shape a non-empty trajectory using one fixed modal-parameter matrix. */
  [[nodiscard]] ShapedSignal
  ShapeTrajectory(const reforge::native::Vector &input,
                  const reforge::native::Matrix &fixed_modal_parameters,
                  bool reset = true);

  /** Shape a non-empty trajectory using one modal matrix per sample. */
  [[nodiscard]] ShapedSignal ShapeTrajectory(
      const reforge::native::Vector &input,
      const std::vector<reforge::native::Matrix> &modal_parameters_by_sample,
      bool reset = true);

  /** Advance the stream with held input for a bounded tail.
   *
   * Omit `sample_count` to emit the current active delay.
   */
  [[nodiscard]] std::vector<ShapedSample>
  Finalize(std::optional<std::int64_t> sample_count = std::nullopt);

  /** Calculate a combined ZVD impulse without mutating stream state. */
  [[nodiscard]] ZvdImpulse
  ComputeZvdShaper(const reforge::native::Matrix &modal_parameters) const;

  /** Clear continuation state while retaining the output-neutral impulse cache. */
  void ResetState();

private:
  /** Shape one input with an already validated impulse. */
  [[nodiscard]] ShapedSample
  ShapePreparedSample(double input, const ZvdImpulse &impulse);

  friend class SharedAxisShaperSession;
  class Impl;
  std::unique_ptr<Impl> impl_;
};

/** Store one shared-axis block result without exposing continuation storage. */
struct REFORGE_SHAPER_EXPORT SharedAxisShapingResult final {
  reforge::native::Matrix positions;
  reforge::native::Matrix velocities;
  reforge::native::Matrix accelerations;
  reforge::native::IntVector delay_samples_by_input;
};

/** Own aligned continuation state for a shared-impulse multi-axis stream. */
class REFORGE_SHAPER_EXPORT SharedAxisShaperSession final {
public:
  /** Construct one persistent native shared-axis shaping session.
   *
   * Args:
   *     axis_count: Positive number of shaped command axes.
   *     sample_time_s: Positive controller sample period [s].
   *     max_delay_samples: Optional fixed non-negative delay capacity
   *         [samples].
   */
  SharedAxisShaperSession(
      std::int64_t axis_count, double sample_time_s,
      std::optional<std::int64_t> max_delay_samples = std::nullopt);
  ~SharedAxisShaperSession();
  SharedAxisShaperSession(SharedAxisShaperSession &&) noexcept;
  SharedAxisShaperSession &operator=(SharedAxisShaperSession &&) noexcept;
  SharedAxisShaperSession(const SharedAxisShaperSession &) = delete;
  SharedAxisShaperSession &operator=(const SharedAxisShaperSession &) = delete;

  /** Return the configured axis count. */
  [[nodiscard]] std::int64_t axis_count() const noexcept;

  /** Return one active delay per axis [samples]. */
  [[nodiscard]] reforge::native::IntVector delay_samples_by_axis() const;

  /** Return held raw inputs, or an empty vector before initial seeding. */
  [[nodiscard]] reforge::native::Vector held_inputs() const;

  /** Return cumulative shared validation and scalar-axis diagnostics. */
  [[nodiscard]] BaseShaperDiagnostics diagnostics() const noexcept;

  /** Shape a shared-parameter command block and retain native continuation. */
  [[nodiscard]] SharedAxisShapingResult
  ShapeTrajectory(const reforge::native::Matrix &command,
                  const std::vector<reforge::native::Matrix>
                      &shared_modal_parameters_by_sample);

  /** Finalize every aligned axis for one common tail length.
   *
   * Omit `sample_count` to emit the common active delay.
   */
  [[nodiscard]] SharedAxisShapingResult
  Finalize(std::optional<std::int64_t> sample_count = std::nullopt);

  /** Clear continuation state while retaining the output-neutral impulse cache. */
  void ResetState();

private:
  class Impl;
  std::unique_ptr<Impl> impl_;
};

} // namespace reforge::control::runtime
