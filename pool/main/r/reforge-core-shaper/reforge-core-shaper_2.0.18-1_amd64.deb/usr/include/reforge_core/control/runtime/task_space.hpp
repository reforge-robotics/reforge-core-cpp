#pragma once

#include <cstddef>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"
#include "reforge_core/util/robot_dynamics.hpp"

namespace reforge::control::runtime {

inline constexpr double kQuaternionLinearInterpolationDotThreshold = 0.9995;

/** Own one normalized task-space command trajectory.
 *
 * Positions are sample-major meters. Orientations, when present, are
 * sample-major normalized XYZW quaternions.
 */
struct REFORGE_SHAPER_EXPORT TaskSpaceCommand final {
    reforge::native::Matrix positions_m;
    std::optional<reforge::native::Matrix> orientations_xyzw;
};

/** Own one native IK solution and its optional solver report.
 *
 * Built-in native solves always provide a report. Binding-only callback
 * bridges may omit it because the frozen Python callback returns only a joint
 * vector.
 */
struct REFORGE_SHAPER_EXPORT TaskSpaceIkResult final {
    reforge::native::Vector joint_positions_rad;
    std::optional<reforge::util::InverseKinematicsReport> report;
};

/** Own a sequential task-space IK path and sample-aligned optional reports. */
struct REFORGE_SHAPER_EXPORT TaskSpaceIkPathResult final {
    reforge::native::Matrix joint_positions_rad;
    std::vector<std::optional<reforge::util::InverseKinematicsReport>> reports;
};

/** Configure the built-in native task-space IK adapter. */
struct REFORGE_SHAPER_EXPORT TaskSpaceIkOptions final {
    std::optional<std::pair<reforge::native::Vector, reforge::native::Vector>>
        joint_limits_rad;
    std::size_t max_iterations = 200;
    double tolerance = 1.0e-8;
    double step_limit_rad = 0.1;
    double damping = 1.0e-3;
    std::optional<std::string> link_name;
};

/** Define the Python-independent sequential task-space IK boundary. */
class REFORGE_SHAPER_EXPORT TaskSpaceIkSolver {
public:
    /** Destroy the solver through its public interface. */
    virtual ~TaskSpaceIkSolver() = default;

    /** Return the required public joint-vector length. */
    [[nodiscard]] virtual std::size_t JointCount() const noexcept = 0;

    /** Solve one position or pose target from a public joint seed.
     *
     * Args:
     *     target: Position `[x, y, z]` or pose
     *         `[x, y, z, qx, qy, qz, qw]`.
     *     seed_joint_positions_rad: Initial joint vector [rad].
     *
     * Returns:
     *     Owned joint solution and optional diagnostic report.
     */
    [[nodiscard]] virtual TaskSpaceIkResult Solve(
        const reforge::native::Vector& target,
        const reforge::native::Vector& seed_joint_positions_rad) = 0;
};

/** Adapt the qualified native dynamics IK implementation to task-space use.
 *
 * The caller owns the dynamics service and workspace for the lifetime of this
 * adapter. Position-only targets preserve the seed's current TCP orientation.
 */
class REFORGE_SHAPER_EXPORT BuiltInTaskSpaceIkSolver final
    : public TaskSpaceIkSolver {
public:
    /** Store borrowed dynamics resources and owned solver options.
     *
     * Args:
     *     dynamics: Immutable-model dynamics service.
     *     workspace: Session-local mutable dynamics workspace.
     *     options: IK limits, tolerances, and optional target link.
     */
    BuiltInTaskSpaceIkSolver(
        const reforge::util::Dynamics& dynamics,
        reforge::util::DynamicsWorkspace& workspace,
        TaskSpaceIkOptions options = {});

    /** Return the dynamics model's public joint count. */
    [[nodiscard]] std::size_t JointCount() const noexcept override;

    /** Solve one position or pose target with the native dynamics service. */
    [[nodiscard]] TaskSpaceIkResult Solve(
        const reforge::native::Vector& target,
        const reforge::native::Vector& seed_joint_positions_rad) override;

private:
    const reforge::util::Dynamics* dynamics_;
    reforge::util::DynamicsWorkspace* workspace_;
    TaskSpaceIkOptions options_;
};

/** Validate and split a task command shaped `[N, 3]` or `[N, 7]`. */
[[nodiscard]] REFORGE_SHAPER_EXPORT TaskSpaceCommand NormalizeTaskSpaceCommand(
    const reforge::native::Matrix& command);

/** Return a validated explicit or controller-rate task time vector [s]. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Vector
NormalizeTaskTimeVector(
    const std::optional<reforge::native::Vector>& time_s,
    std::size_t samples,
    double sample_time_s);

/** Normalize a sample-major sequence of finite XYZW quaternions. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Matrix
NormalizeQuaternionSequence(
    const reforge::native::Matrix& quaternions_xyzw);

/** Interpolate two XYZW quaternions along the shortest spherical path. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Vector
SlerpQuaternionPair(
    const reforge::native::Vector& start_xyzw,
    const reforge::native::Vector& end_xyzw,
    double alpha);

/** Interpolate normalized XYZW quaternions at query times [s]. */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Matrix
SlerpQuaternionSequence(
    const reforge::native::Vector& sample_times_s,
    const reforge::native::Matrix& quaternions_xyzw,
    const reforge::native::Vector& query_times_s);

/** Align raw orientations to a shaped translation path.
 *
 * Nondegenerate translations map shaped cumulative path coordinates back to
 * raw command time. Degenerate translations fall back to shaped output time.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT reforge::native::Matrix
AlignOrientationsToTranslationPath(
    const reforge::native::Matrix& raw_positions_m,
    const reforge::native::Matrix& raw_orientations_xyzw,
    const reforge::native::Vector& raw_time_s,
    const reforge::native::Matrix& shaped_positions_m,
    const reforge::native::Vector& shaped_time_s);

/** Solve a task command sequentially, seeding each sample from its predecessor.
 *
 * Args:
 *     command: Normalized task-space command.
 *     initial_joint_positions_rad: Initial public joint seed [rad].
 *     solver: Native solver or binding-only callback bridge.
 *     require_reported_convergence: Reject a reported non-converged result.
 *         Results without reports remain valid for callback compatibility.
 *
 * Returns:
 *     Owned joint path and sample-aligned optional reports.
 *
 * Raises:
 *     reforge::native::Error: If a solver reports non-convergence.
 *     reforge::native::InvalidArgumentError: If inputs or solver output are
 *         malformed or non-finite.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT TaskSpaceIkPathResult SolveTaskSpaceIkPath(
    const TaskSpaceCommand& command,
    const reforge::native::Vector& initial_joint_positions_rad,
    TaskSpaceIkSolver& solver,
    bool require_reported_convergence = true);

}  // namespace reforge::control::runtime
