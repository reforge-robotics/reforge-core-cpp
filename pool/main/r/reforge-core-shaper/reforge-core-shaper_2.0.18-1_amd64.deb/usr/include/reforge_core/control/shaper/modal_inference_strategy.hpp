#pragma once

#include <string_view>

#include "reforge_core/native/common/export.hpp"

namespace reforge::control::shaper {

/** Select fixed or per-sample adaptive modal inference. */
enum class ModalInferenceStrategy {
    kFixed,
    kAdaptive,
};

/** Return the exact persisted value for a modal inference strategy.
 *
 * Args:
 *     strategy: Native strategy value.
 *
 * Returns:
 *     Exact lowercase strategy identifier.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT std::string_view ToString(
    ModalInferenceStrategy strategy) noexcept;

/** Parse an exact persisted modal inference strategy value.
 *
 * Args:
 *     value: Exact lowercase strategy identifier.
 *
 * Returns:
 *     Parsed native strategy.
 *
 * Raises:
 *     InvalidArgumentError: If `value` is unsupported.
 */
[[nodiscard]] REFORGE_SHAPER_EXPORT ModalInferenceStrategy
ParseModalInferenceStrategy(std::string_view value);

}  // namespace reforge::control::shaper
