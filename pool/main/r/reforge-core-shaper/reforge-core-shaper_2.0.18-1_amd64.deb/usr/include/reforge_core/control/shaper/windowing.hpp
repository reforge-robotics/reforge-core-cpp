#pragma once

#include <cstddef>
#include <memory>
#include <optional>
#include <vector>

#include "reforge_core/control/python/windowed_buffer.hpp"
#include "reforge_core/control/runtime/task_space.hpp"
#include "reforge_core/control/shaper/modal_inference_strategy.hpp"
#include "reforge_core/control/shaper/residual_alignment.hpp"
#include "reforge_core/control/shaper/residual_switch.hpp"
#include "reforge_core/control/window/shaper_window_handle.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::shaper {

/** Select the finite-trajectory residual shaping policy. */
enum class ResidualShapingStrategy {
    kAlignedTail,
};

/** Configure one native finite shaper window session. */
struct REFORGE_SHAPER_EXPORT ShaperWindowRequest final {
    reforge::native::Matrix command_rad;
    std::optional<reforge::native::Matrix> command_velocity_rad_s;
    std::optional<reforge::native::Matrix> command_acceleration_rad_s2;
    std::optional<reforge::native::Vector> time_s;
    double vibration_shaping_weight = 1.0;
    std::optional<reforge::native::Vector> vibration_shaping_weight_profile;
    std::optional<ResidualShapingStrategy> residual_shaping_strategy =
        ResidualShapingStrategy::kAlignedTail;
    double residual_transition_margin_s = 0.0;
    std::optional<ResidualSwitchLimits> residual_switch_limits;
    double window_s = 0.0;
    std::size_t prefill_windows = 1;
    bool finalize_tail = true;
    bool reset_on_start = true;
    ModalInferenceStrategy modal_inference_strategy =
        ModalInferenceStrategy::kFixed;
};

/** Configure one native task-space window session. */
struct REFORGE_SHAPER_EXPORT TaskSpaceWindowRequest final {
    reforge::native::Matrix command;
    reforge::native::Vector initial_joint_angles_rad;
    std::optional<reforge::native::Vector> time_s;
    double vibration_shaping_weight = 1.0;
    std::optional<reforge::native::Vector> vibration_shaping_weight_profile;
    std::optional<ResidualShapingStrategy> residual_shaping_strategy =
        ResidualShapingStrategy::kAlignedTail;
    double residual_transition_margin_s = 0.0;
    double window_s = 0.0;
    std::size_t prefill_windows = 1;
    bool finalize_tail = true;
    bool reset_on_start = true;
    ModalInferenceStrategy modal_inference_strategy =
        ModalInferenceStrategy::kFixed;
};

/** Report real-time qualification for one shaper window duration. */
struct REFORGE_SHAPER_EXPORT ShaperWindowQualificationResult final {
    double window_s = 0.0;
    bool passed = false;
    double compute_fraction_limit = 0.0;
    std::size_t prefill_windows = 0;
    double max_window_s = 0.0;
    double p99_window_s = 0.0;
    double min_buffer_margin_s = 0.0;
    std::size_t underruns = 0;
    std::size_t measured_windows = 0;
    double qualification_elapsed_s = 0.0;
};

/** Define complete native operations consumed by shaper window adapters.
 *
 * Implementations own modal inference and persistent shaper continuation.
 * Window adapters receive only complete trajectories, fixed snapshots, and
 * bounded tail operations; they never inspect individual shaper buffers.
 */
class REFORGE_SHAPER_EXPORT ShaperWindowRuntime {
  public:
    virtual ~ShaperWindowRuntime() = default;

    /** Return the positive native controller sample period [s]. */
    [[nodiscard]] virtual double SampleTimeS() const noexcept = 0;

    /** Return the configured joint count. */
    [[nodiscard]] virtual std::size_t NumJoints() const noexcept = 0;

    /** Return whether residual targets require a quiet acceleration region. */
    [[nodiscard]] virtual bool
    RequireZeroAccelerationRegion() const noexcept = 0;

    /** Reset all shaping and modal snapshot state. */
    virtual void Reset() = 0;

    /** Generate one opaque numeric state row per command sample. */
    [[nodiscard]] virtual reforge::native::Matrix
    GenerateStates(const reforge::native::Matrix& command_rad) = 0;

    /** Select one per-axis modal snapshot for a finite trajectory. */
    [[nodiscard]] virtual std::vector<reforge::native::Matrix>
    SelectFixedModalSnapshot(
        const reforge::native::Matrix& states,
        const reforge::native::Matrix& path_velocity_rad_s,
        const reforge::native::Matrix& path_acceleration_rad_s2) = 0;

    /** Select the exact attach-point snapshot for residual candidate scoring.
     */
    [[nodiscard]] virtual std::vector<reforge::native::Matrix>
    SelectResidualModalSnapshot(
        const reforge::native::Matrix& states,
        const reforge::native::Matrix& path_velocity_rad_s,
        const reforge::native::Matrix& path_acceleration_rad_s2,
        std::size_t attach_index,
        ModalInferenceStrategy modal_inference_strategy,
        const std::vector<reforge::native::Matrix>&
            fixed_modal_params_by_axis) = 0;

    /** Project joint sample columns to the configured residual path axes. */
    [[nodiscard]] virtual reforge::native::Matrix
    ResidualPathValues(const reforge::native::Matrix& values) const = 0;

    /** Shape one source window while preserving native continuation. */
    [[nodiscard]] virtual reforge::native::ShapedTrajectory ProcessWindow(
        const reforge::control::window::TrajectoryWindow& window,
        double vibration_shaping_weight,
        const std::optional<reforge::native::Vector>& weight_profile,
        const std::vector<reforge::native::Matrix>& fixed_modal_params_by_axis,
        ModalInferenceStrategy modal_inference_strategy) = 0;

    /** Drain every remaining delayed sample for residual branch alignment. */
    [[nodiscard]] virtual reforge::native::ShapedTrajectory
    FinalizeTail(const reforge::native::Vector& last_position_rad,
                 double last_time_s, std::size_t start_index) = 0;

    /** Drain one bounded delayed-output chunk for ordinary window tails. */
    [[nodiscard]] virtual reforge::native::ShapedTrajectory
    ShapeTailChunk(const reforge::native::Vector& last_position_rad,
                   double last_time_s, std::size_t start_index,
                   std::size_t sample_count,
                   const std::vector<std::size_t>& remaining_by_axis) = 0;

    /** Return the most recent shaped position or the supplied fallback. */
    [[nodiscard]] virtual reforge::native::Vector LastShapedPosition(
        const reforge::native::Vector& fallback_position_rad) const = 0;

    /** Return remaining delayed-output support for every shaped axis. */
    [[nodiscard]] virtual std::vector<std::size_t>
    TailSupportSamples() const = 0;

    /** Return the current scalar raw-to-shaped blend weight. */
    [[nodiscard]] virtual double
    CurrentVibrationShapingWeight() const noexcept = 0;
};

/** Define complete native task-space processing consumed by its adapter. */
class REFORGE_SHAPER_EXPORT TaskSpaceWindowRuntime {
  public:
    virtual ~TaskSpaceWindowRuntime() = default;

    /** Return the positive native controller sample period [s]. */
    [[nodiscard]] virtual double SampleTimeS() const noexcept = 0;

    /** Return the configured joint count. */
    [[nodiscard]] virtual std::size_t NumJoints() const noexcept = 0;

    /** Process one complete task-space request without Python callbacks. */
    [[nodiscard]] virtual reforge::control::window::TaskSpaceShapedTrajectory
    ProcessTaskSpaceTrajectory(const TaskSpaceWindowRequest& request) = 0;

    /** Process task space with one borrowed explicit native IK solver. */
    [[nodiscard]] virtual reforge::control::window::TaskSpaceShapedTrajectory
    ProcessTaskSpaceTrajectoryWithSolver(
        const TaskSpaceWindowRequest& request,
        reforge::control::runtime::TaskSpaceIkSolver& ik_solver) = 0;

    /** Reset native task-space and shaping continuation state. */
    virtual void Reset() = 0;
};

/** Slice finite source trajectories and construct native window sessions. */
class REFORGE_SHAPER_EXPORT WindowingService final {
  public:
    /** Construct the service around non-owning complete native runtimes. */
    WindowingService(ShaperWindowRuntime& shaper_runtime,
                     TaskSpaceWindowRuntime* task_space_runtime = nullptr);
    ~WindowingService();
    WindowingService(WindowingService&&) noexcept;
    WindowingService& operator=(WindowingService&&) noexcept;
    WindowingService(const WindowingService&) = delete;
    WindowingService& operator=(const WindowingService&) = delete;

    /** Slice one finite command into ordered source windows. */
    [[nodiscard]] std::vector<reforge::control::window::TrajectoryWindow>
    MakeTrajectoryWindows(
        const reforge::native::Matrix& command_rad,
        const std::optional<reforge::native::Matrix>& command_velocity_rad_s,
        const std::optional<reforge::native::Matrix>&
            command_acceleration_rad_s2,
        const std::optional<reforge::native::Vector>& time_s,
        const std::optional<reforge::native::Vector>& weight_profile,
        double window_s);

    /** Create one lifecycle-owned finite joint window handle. */
    [[nodiscard]] std::unique_ptr<
        reforge::control::window::TrajectoryWindowHandle>
    CreateWindowedBuffer(const ShaperWindowRequest& request);

    /** Create one generic async-compatible shaper producer session. */
    [[nodiscard]] std::unique_ptr<
        reforge::control::window::WindowProducerSession>
    CreateWindowProducer(const ShaperWindowRequest& request);

    /** Measure one candidate window against the real-time timing gate. */
    [[nodiscard]] ShaperWindowQualificationResult
    QualifyWindowedBuffer(const ShaperWindowRequest& request,
                          double compute_fraction_limit);

    /** Return the first candidate duration that passes qualification. */
    [[nodiscard]] ShaperWindowQualificationResult
    SelectQualifiedWindow(const ShaperWindowRequest& request,
                          const std::vector<double>& window_candidates_s,
                          double compute_fraction_limit);

    /** Create one lifecycle-owned precomputed task-space window handle. */
    [[nodiscard]] std::unique_ptr<
        reforge::control::window::TaskSpaceWindowHandle>
    CreateTaskSpaceWindowedBuffer(const TaskSpaceWindowRequest& request);

    /** Create a task-space handle using one borrowed explicit IK solver. */
    [[nodiscard]] std::unique_ptr<
        reforge::control::window::TaskSpaceWindowHandle>
    CreateTaskSpaceWindowedBufferWithSolver(
        const TaskSpaceWindowRequest& request,
        reforge::control::runtime::TaskSpaceIkSolver& ik_solver);

    /** Return diagnostics from the latest completed constrained window solve.
     */
    [[nodiscard]] std::optional<ResidualSwitchSearchDiagnostics>
    LastResidualSwitchDiagnostics() const;

  private:
    /** Validate, process, and slice task space with optional explicit IK. */
    [[nodiscard]] std::unique_ptr<
        reforge::control::window::TaskSpaceWindowHandle>
    CreateTaskSpaceWindowedBufferImpl(
        const TaskSpaceWindowRequest& request,
        reforge::control::runtime::TaskSpaceIkSolver* ik_solver);

    class Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace reforge::control::shaper
