#pragma once

#include <cstddef>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <Eigen/Core>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::util {

inline constexpr double kContinuousJointLowerLimitRad =
    -2.0 * 3.14159265358979323846;
inline constexpr double kContinuousJointUpperLimitRad =
    2.0 * 3.14159265358979323846;
inline constexpr std::size_t kPinocchioUniverseJointIndex = 0;

/** Describe the final task-space accuracy of an inverse-kinematics solve. */
struct REFORGE_SHAPER_EXPORT InverseKinematicsReport final {
    reforge::native::Vector position_error_m;
    reforge::native::Vector rotation_error_rad;
    double position_error_magnitude_m;
    double rotation_error_magnitude_rad;
    std::size_t num_iterations;
    bool converged;
};

/** Own an inverse-kinematics solution and its final diagnostic report. */
struct REFORGE_SHAPER_EXPORT InverseKinematicsResult final {
    reforge::native::Vector joint_positions;
    InverseKinematicsReport report;
};

/** Own one forward-kinematics position and XYZW orientation result. */
struct REFORGE_SHAPER_EXPORT ForwardKinematicsResult final {
    reforge::native::Vector position_m;
    reforge::native::Vector quaternion_xyzw;
};

/** Own sample-major forward-kinematics positions and XYZW orientations. */
struct REFORGE_SHAPER_EXPORT ForwardKinematicsBatchResult final {
    reforge::native::Matrix positions_m;
    reforge::native::Matrix quaternions_xyzw;
};

/** Store immutable, shareable Pinocchio model data loaded from a URDF. */
class REFORGE_SHAPER_EXPORT DynamicsModel final {
public:
    /** Forward-declare the hidden Pinocchio-backed implementation. */
    struct Impl;

    /** Load and validate an immutable dynamics model.
     *
     * Args:
     *     urdf_path: Path to a regular URDF file.
     *     initial_joint_positions: Optional public scalar joint vector used
     *         only for construction-time shape validation.
     *     tcp_payload_mass_kg: Nonnegative payload mass attached at the TCP.
     *     tcp_payload_com_m: Payload COM in TCP coordinates [m].
     *
     * Raises:
     *     reforge::native::Error: If the path, URDF, joint layout, frames,
     *         payload, or initial vector is invalid.
     */
    explicit DynamicsModel(
        std::string urdf_path,
        std::optional<reforge::native::Vector> initial_joint_positions =
            std::nullopt,
        double tcp_payload_mass_kg = 0.0,
        Eigen::Vector3d tcp_payload_com_m = Eigen::Vector3d::Zero());

    /** Destroy the hidden Pinocchio-backed implementation. */
    ~DynamicsModel();

    DynamicsModel(const DynamicsModel&) = delete;
    DynamicsModel& operator=(const DynamicsModel&) = delete;
    DynamicsModel(DynamicsModel&&) noexcept;
    DynamicsModel& operator=(DynamicsModel&&) noexcept;

    /** Return the resolved URDF path used to build the model. */
    [[nodiscard]] const std::string& urdf_path() const noexcept;

    /** Return public movable-joint count. */
    [[nodiscard]] std::size_t joint_count() const noexcept;

    /** Return public movable-joint names in Pinocchio model order. */
    [[nodiscard]] const std::vector<std::string>& joint_names() const noexcept;

    /** Return URDF BODY-frame names in deterministic model order. */
    [[nodiscard]] const std::vector<std::string>& link_names() const noexcept;

    /** Return public lower joint limits [rad or m]. */
    [[nodiscard]] const reforge::native::Vector& lower_joint_limits() const noexcept;

    /** Return public upper joint limits [rad or m]. */
    [[nodiscard]] const reforge::native::Vector& upper_joint_limits() const noexcept;

    /** Return the attached TCP payload mass [kg]. */
    [[nodiscard]] double tcp_payload_mass_kg() const noexcept;

    /** Return the attached payload COM in TCP coordinates [m]. */
    [[nodiscard]] const Eigen::Vector3d& tcp_payload_com_m() const noexcept;

private:
    std::shared_ptr<const Impl> impl_;

    friend class Dynamics;
    friend class DynamicsWorkspace;
};

/** Own mutable Pinocchio scratch for one model and one calling thread. */
class REFORGE_SHAPER_EXPORT DynamicsWorkspace final {
public:
    /** Forward-declare the hidden mutable scratch implementation. */
    struct Impl;

    /** Construct scratch storage associated with exactly one model.
     *
     * Args:
     *     model: Immutable model whose operations may use this workspace.
     */
    explicit DynamicsWorkspace(const DynamicsModel& model);

    /** Destroy the hidden Pinocchio-backed scratch implementation. */
    ~DynamicsWorkspace();

    DynamicsWorkspace(const DynamicsWorkspace&) = delete;
    DynamicsWorkspace& operator=(const DynamicsWorkspace&) = delete;
    DynamicsWorkspace(DynamicsWorkspace&&) noexcept;
    DynamicsWorkspace& operator=(DynamicsWorkspace&&) noexcept;

    /** Reserve ordinary batch-result capacity for at least `max_samples`. */
    void PrepareBatch(std::size_t max_samples);

    /** Reserve inverse-kinematics scratch needed by the associated model. */
    void PrepareInverseKinematics();

private:
    /** Return scratch after verifying exact immutable-model identity. */
    [[nodiscard]] Impl& CheckedImpl(const DynamicsModel& model);

    std::unique_ptr<Impl> impl_;

    friend class Dynamics;
};

/** Provide Python-independent kinematics and dynamics operations for a URDF. */
class REFORGE_SHAPER_EXPORT Dynamics {
public:
    /** Construct a service around a newly loaded immutable model.
     *
     * Args:
     *     urdf_path: Path to a regular URDF file.
     *     initial_joint_positions: Optional public scalar joint vector used
     *         only for construction-time shape validation.
     *     tcp_payload_mass_kg: Nonnegative payload mass attached at the TCP.
     *     tcp_payload_com_m: Payload COM in TCP coordinates [m].
     */
    explicit Dynamics(
        std::string urdf_path,
        std::optional<reforge::native::Vector> initial_joint_positions =
            std::nullopt,
        double tcp_payload_mass_kg = 0.0,
        Eigen::Vector3d tcp_payload_com_m = Eigen::Vector3d::Zero());

    /** Construct a service around an existing immutable model.
     *
     * Args:
     *     model: Shared model used by the service.
     */
    explicit Dynamics(std::shared_ptr<const DynamicsModel> model);

    /** Return the immutable model used by this service. */
    [[nodiscard]] const DynamicsModel& model() const noexcept;

    /** Return public movable-joint count. */
    [[nodiscard]] std::size_t joint_count() const noexcept;

    /** Return public movable-joint names in Pinocchio model order. */
    [[nodiscard]] const std::vector<std::string>& joint_names() const noexcept;

    /** Return URDF BODY-frame names in deterministic model order. */
    [[nodiscard]] const std::vector<std::string>& link_names() const noexcept;

    /** Return detached lower and upper public joint limits [rad or m]. */
    [[nodiscard]] std::pair<reforge::native::Vector, reforge::native::Vector>
    joint_limits() const;

    /** Retain the Python compatibility no-op. */
    void ComputeParams() const noexcept;

    /** Retain the Python compatibility no-op. */
    void InitializeModel() const noexcept;

    /** Return a symmetric joint-space mass matrix. */
    [[nodiscard]] reforge::native::Matrix GetMassMatrix(
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace) const;

    /** Return mass matrices in sample order. */
    [[nodiscard]] std::vector<reforge::native::Matrix> GetMassMatricesBatch(
        const reforge::native::Matrix& joint_position_samples,
        DynamicsWorkspace& workspace) const;

    /** Return the selected frame Jacobian with linear rows before angular rows. */
    [[nodiscard]] reforge::native::Matrix GetJacobianMatrix(
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace,
        const std::optional<std::string>& link_name = std::nullopt) const;

    /** Return default-TCP Jacobians in sample order. */
    [[nodiscard]] std::vector<reforge::native::Matrix> GetJacobianMatricesBatch(
        const reforge::native::Matrix& joint_position_samples,
        DynamicsWorkspace& workspace) const;

    /** Return the selected frame world transform. */
    [[nodiscard]] reforge::native::Matrix GetTransformationMatrix(
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace,
        const std::optional<std::string>& link_name = std::nullopt) const;

    /** Return default-TCP world transforms in sample order. */
    [[nodiscard]] std::vector<reforge::native::Matrix>
    GetTransformationMatricesBatch(
        const reforge::native::Matrix& joint_position_samples,
        DynamicsWorkspace& workspace) const;

    /** Return one legacy indexed moving-link transform. */
    [[nodiscard]] reforge::native::Matrix GetIndividualTransformationMatrix(
        std::size_t index,
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace) const;

    /** Return the default-TCP rotation matrix. */
    [[nodiscard]] reforge::native::Matrix GetRotationMatrix(
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace) const;

    /** Return default-TCP rotations in sample order. */
    [[nodiscard]] std::vector<reforge::native::Matrix> GetRotationMatricesBatch(
        const reforge::native::Matrix& joint_position_samples,
        DynamicsWorkspace& workspace) const;

    /** Return one legacy indexed moving-link rotation. */
    [[nodiscard]] reforge::native::Matrix GetIndividualRotationMatrix(
        std::size_t index,
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace) const;

    /** Return moving-joint origins in public joint order [m]. */
    [[nodiscard]] std::vector<reforge::native::Vector> GetPositionVectors(
        DynamicsWorkspace& workspace,
        const std::optional<reforge::native::Vector>& joint_positions =
            std::nullopt) const;

    /** Return default-TCP position and deterministic XYZW quaternion. */
    [[nodiscard]] ForwardKinematicsResult GetForwardKinematics(
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace) const;

    /** Return default-TCP positions and quaternions in sample order. */
    [[nodiscard]] ForwardKinematicsBatchResult GetForwardKinematicsBatch(
        const reforge::native::Matrix& joint_position_samples,
        DynamicsWorkspace& workspace) const;

    /** Return all URDF BODY-frame transforms in `link_names()` order. */
    [[nodiscard]] std::vector<reforge::native::Matrix> GetLinkTransforms(
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace) const;

    /** Return all named URDF BODY-frame transforms in model order. */
    [[nodiscard]] std::vector<
        std::pair<std::string, reforge::native::Matrix>>
    GetLinkTransformEntries(
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace) const;

    /** Solve iterative damped or undamped inverse kinematics.
     *
     * Args:
     *     target_pose: Target `[x, y, z, qx, qy, qz, qw]`.
     *     initial_joint_positions: Initial public scalar vector.
     *     workspace: Caller-owned mutable scratch.
     *     joint_limits: Optional lower and upper public solver limits.
     *     max_iterations: Maximum update iterations.
     *     tolerance: Full six-dimensional pose-error tolerance.
     *     step_limit: Maximum complete joint update norm per iteration.
     *     damping: Nonnegative damped-least-squares factor.
     *     link_name: Optional target BODY frame; defaults to the TCP.
     *
     * Returns:
     *     Final public joint vector and an always-populated report.
     */
    [[nodiscard]] InverseKinematicsResult GetInverseKinematics(
        const reforge::native::Vector& target_pose,
        const reforge::native::Vector& initial_joint_positions,
        DynamicsWorkspace& workspace,
        const std::optional<
            std::pair<reforge::native::Vector, reforge::native::Vector>>&
            joint_limits = std::nullopt,
        std::size_t max_iterations = 200,
        double tolerance = 1e-8,
        double step_limit = 0.1,
        double damping = 1e-3,
        const std::optional<std::string>& link_name = std::nullopt) const;

    /** Return generalized gravity compensation for a world acceleration. */
    [[nodiscard]] reforge::native::Vector GetGravityTorque(
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace,
        const Eigen::Vector3d& gravity_world_m_per_s2 =
            Eigen::Vector3d(0.0, 0.0, -9.81)) const;

    /** Return generalized gravity compensation in sample order. */
    [[nodiscard]] reforge::native::Matrix GetGravityTorquesBatch(
        const reforge::native::Matrix& joint_position_samples,
        DynamicsWorkspace& workspace,
        const Eigen::Vector3d& gravity_world_m_per_s2 =
            Eigen::Vector3d(0.0, 0.0, -9.81)) const;

    /** Return world-frame motion axes in public joint order. */
    [[nodiscard]] std::vector<reforge::native::Vector> GetJointAxes(
        const reforge::native::Vector& joint_positions,
        DynamicsWorkspace& workspace) const;

private:
    std::shared_ptr<const DynamicsModel> model_;
};

}  // namespace reforge::util
