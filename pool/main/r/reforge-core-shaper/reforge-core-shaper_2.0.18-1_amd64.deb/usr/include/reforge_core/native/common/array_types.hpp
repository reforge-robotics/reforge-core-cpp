#pragma once

#include <cstdint>

#include <Eigen/Core>

namespace reforge::native {

/** Own a dynamic vector of double-precision domain values. */
using Vector = Eigen::VectorXd;

/** Own a dynamic vector of stable signed indexes. */
using IntVector = Eigen::Matrix<std::int64_t, Eigen::Dynamic, 1>;

/** Own a sample-major, row-major matrix of double-precision domain values. */
using Matrix =
    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;

/** Own a sample-major, row-major matrix of float model values. */
using FloatMatrix =
    Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;

/** Own sample-aligned shaped joint kinematics and timestamps. */
struct ShapedTrajectory final {
    Matrix positions;
    Matrix velocities;
    Matrix accelerations;
    Vector time;
};

}  // namespace reforge::native
