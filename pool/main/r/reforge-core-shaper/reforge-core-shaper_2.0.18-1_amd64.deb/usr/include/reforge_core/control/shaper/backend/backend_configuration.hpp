#pragma once

#include <cstddef>
#include <filesystem>
#include <optional>

#include "reforge_core/control/runtime/modal_inference.hpp"
#include "reforge_core/control/shaper/residual_alignment.hpp"
#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"

namespace reforge::control::shaper::backend {

/** Own immutable construction inputs for one complete native shaper session. */
struct REFORGE_SHAPER_EXPORT BackendConfiguration final {
    double sample_time_s = 0.0;
    std::filesystem::path model_directory;
    std::filesystem::path urdf_filepath;
    std::size_t num_axes = 5;
    double side_length_m = 0.125;
    double base_height_m = 0.290;
    std::size_t num_joints = 6;
    double probability_threshold = 0.5;
    reforge::control::runtime::SharedImpulsePolicy shared_impulse_policy =
        reforge::control::runtime::SharedImpulsePolicy::kAxis0;
    bool shared_impulse_shapes_all_joints = true;
    reforge::control::shaper::ResidualPathScope residual_path_scope =
        reforge::control::shaper::ResidualPathScope::kShapedAxes;
    bool aligned_tail_require_zero_acceleration_region = false;
    reforge::native::Vector train_base_angles_rad =
        reforge::native::Vector::Zero(1);
    std::optional<reforge::native::Vector> feature_frame_translation_m;
    /** Initial payload mass attached at the TCP [kg]. */
    double tcp_payload_mass_kg = 0.0;
};

/** Validate the complete construction boundary without loading resources. */
REFORGE_SHAPER_EXPORT void Validate(
    const BackendConfiguration& configuration);

/** Describe the availability of a complete native backend session. */
struct REFORGE_SHAPER_EXPORT BackendCapabilities final {
    bool native_backend_available = true;
};

}  // namespace reforge::control::shaper::backend
