#pragma once

#include <chrono>
#include <cstddef>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "reforge_core/native/common/array_types.hpp"
#include "reforge_core/native/common/export.hpp"
#include "reforge_core/util/timing/joint_trajectory.hpp"

namespace reforge::control::window {

/** Own one source slice and its global half-open range. */
struct REFORGE_SHAPER_EXPORT WindowSlice final {
    reforge::native::Matrix positions;
    std::optional<reforge::native::Matrix> velocities;
    std::optional<reforge::native::Matrix> accelerations;
    std::optional<reforge::native::Vector> time_s;
    std::size_t start_index = 0;
    std::size_t stop_index = 0;
    std::map<std::string, std::string> metadata;
};

/** Own one produced window and measured computation time. */
struct REFORGE_SHAPER_EXPORT WindowPayload final {
    reforge::native::Matrix positions;
    std::optional<reforge::native::Matrix> velocities;
    std::optional<reforge::native::Matrix> accelerations;
    std::optional<reforge::native::Vector> time_s;
    std::size_t start_index = 0;
    std::size_t stop_index = 0;
    double compute_time_s = 0.0;
    std::map<std::string, std::string> metadata;
};

/** Report deterministic real-time window qualification measurements. */
struct REFORGE_SHAPER_EXPORT WindowQualificationResult final {
    bool passed = false;
    double compute_fraction_limit = 0.0;
    std::size_t prefill_windows = 0;
    double max_window_s = 0.0;
    double p99_window_s = 0.0;
    double min_buffer_margin_s = 0.0;
    std::size_t underruns = 0;
    std::size_t measured_windows = 0;
    double qualification_elapsed_s = 0.0;
};

/** Validate one source slice and throw for an invalid observable value. */
REFORGE_SHAPER_EXPORT void ValidateWindowSlice(const WindowSlice& window);

/** Validate one produced payload and throw for an invalid observable value. */
REFORGE_SHAPER_EXPORT void ValidateWindowPayload(const WindowPayload& payload);

/** Define one native producer session consumed by an async buffer. */
class REFORGE_SHAPER_EXPORT WindowProducerSession {
public:
    virtual ~WindowProducerSession() = default;

    /** Prepare immutable and session-local producer state exactly once. */
    virtual void PrepareSession() = 0;

    /** Produce the next payload, or no value when temporarily unavailable. */
    [[nodiscard]] virtual std::optional<WindowPayload> ProduceNext() = 0;

    /** Return whether no additional regular payload can be produced. */
    [[nodiscard]] virtual bool IsExhausted() const = 0;

    /** Finalize the session and optionally return one terminal payload. */
    [[nodiscard]] virtual std::optional<WindowPayload> Finalize() = 0;
};

/** Own a finite mainline and terminal payload sequence with stable cursors. */
class REFORGE_SHAPER_EXPORT FiniteWindowProducer final
    : public WindowProducerSession {
public:
    /** Construct an owned finite sequence after validating every payload. */
    explicit FiniteWindowProducer(
        std::vector<WindowPayload> windows,
        std::vector<WindowPayload> terminal_windows = {});
    ~FiniteWindowProducer() override;
    FiniteWindowProducer(FiniteWindowProducer&&) noexcept;
    FiniteWindowProducer& operator=(FiniteWindowProducer&&) noexcept;
    FiniteWindowProducer(const FiniteWindowProducer&) = delete;
    FiniteWindowProducer& operator=(const FiniteWindowProducer&) = delete;

    /** Prepare the finite cursor exactly once. */
    void PrepareSession() override;

    /** Return the next mainline payload. */
    [[nodiscard]] std::optional<WindowPayload> ProduceNext() override;

    /** Return whether every mainline payload has been produced. */
    [[nodiscard]] bool IsExhausted() const override;

    /** Return the next terminal payload after mainline exhaustion. */
    [[nodiscard]] std::optional<WindowPayload> Finalize() override;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

/** Own append-only reference samples and deterministic terminal padding. */
class REFORGE_SHAPER_EXPORT AppendableReferenceBuffer final {
public:
    /** Construct an empty reference with optional fixed joint count. */
    explicit AppendableReferenceBuffer(
        std::optional<std::size_t> joint_count = std::nullopt);
    ~AppendableReferenceBuffer();
    AppendableReferenceBuffer(AppendableReferenceBuffer&&) noexcept;
    AppendableReferenceBuffer& operator=(
        AppendableReferenceBuffer&&) noexcept;
    AppendableReferenceBuffer(const AppendableReferenceBuffer&) = delete;
    AppendableReferenceBuffer& operator=(
        const AppendableReferenceBuffer&) = delete;

    /** Append owned sample-major commands and return their global range. */
    [[nodiscard]] std::pair<std::size_t, std::size_t> AppendReference(
        const reforge::native::Matrix& command);

    /** Mark the reference terminal and wake all waiters. */
    void Finish();

    /** Return the number of currently available samples. */
    [[nodiscard]] std::size_t available_samples() const;

    /** Return whether the producer has marked the reference terminal. */
    [[nodiscard]] bool is_finished() const;

    /** Wait for a sample count, terminal state, cancellation, or timeout. */
    [[nodiscard]] bool WaitUntilSamples(
        std::size_t minimum_samples,
        std::optional<std::chrono::steady_clock::duration> timeout =
            std::nullopt);

    /** Extend a finished reference by repeating its terminal sample. */
    [[nodiscard]] std::size_t ExtendHoldTo(std::size_t minimum_samples);

    /** Return an owned snapshot of all currently available positions. */
    [[nodiscard]] reforge::native::Matrix PositionsCopy() const;

    /** Return an owned half-open window with deterministic terminal padding. */
    [[nodiscard]] std::pair<reforge::native::Matrix, std::size_t>
    WindowWithTerminalPadding(
        std::size_t start_index, std::size_t stop_index) const;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

/** Own one worker, queue, producer session, and captured failure. */
class REFORGE_SHAPER_EXPORT AsyncWindowBuffer {
public:
    /** Construct a stopped buffer with validated queue settings. */
    AsyncWindowBuffer(
        std::unique_ptr<WindowProducerSession> producer,
        std::size_t prefill_windows = 0,
        std::optional<std::size_t> max_buffered_windows = std::nullopt);
    virtual ~AsyncWindowBuffer();
    AsyncWindowBuffer(AsyncWindowBuffer&&) noexcept;
    AsyncWindowBuffer& operator=(AsyncWindowBuffer&&) noexcept;
    AsyncWindowBuffer(const AsyncWindowBuffer&) = delete;
    AsyncWindowBuffer& operator=(const AsyncWindowBuffer&) = delete;

    /** Start the single worker; repeated calls are rejected. */
    void Start();

    /** Request cancellation and wake producer/consumer waiters. */
    virtual void Stop();

    /** Join the worker, returning false only on timeout. */
    [[nodiscard]] bool Join(
        std::optional<std::chrono::steady_clock::duration> timeout =
            std::nullopt);

    /** Stop and join the worker, preserving any captured producer error. */
    void Close();

    /** Block for one payload, completion, cancellation, error, or timeout. */
    [[nodiscard]] std::optional<WindowPayload> Pop(
        std::optional<std::chrono::steady_clock::duration> timeout =
            std::nullopt);

    /** Return one queued payload without blocking. */
    [[nodiscard]] std::optional<WindowPayload> PopNowait();

    /** Return whether at least one payload is queued. */
    [[nodiscard]] bool HasBufferedData() const;

    /** Return whether production and queued consumption are complete. */
    [[nodiscard]] bool IsComplete() const;

    /** Return the captured worker failure text, if any. */
    [[nodiscard]] std::optional<std::string> LastError() const;

    /** Produce synchronously until count, exhaustion, or failure. */
    [[nodiscard]] std::size_t Prefill(std::size_t count);

    /** Measure production timing without consuming the retained payloads. */
    [[nodiscard]] WindowQualificationResult Qualify(
        double compute_fraction_limit);

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

/** Compose async production with one appendable reference owner. */
class REFORGE_SHAPER_EXPORT AppendableWindowBuffer final
    : public AsyncWindowBuffer {
public:
    /** Construct an appendable async window session. */
    AppendableWindowBuffer(
        std::unique_ptr<WindowProducerSession> producer,
        std::shared_ptr<AppendableReferenceBuffer> reference_buffer,
        std::size_t prefill_windows = 0,
        std::optional<std::size_t> max_buffered_windows = std::nullopt);

    /** Append commands and return their global range. */
    [[nodiscard]] std::pair<std::size_t, std::size_t> AppendReference(
        const reforge::native::Matrix& command);

    /** Mark the reference terminal. */
    void Finish();

    /** Stop the worker and wake reference waiters. */
    void Stop() override;

    /** Return an owned reference snapshot. */
    [[nodiscard]] reforge::native::Matrix ReferencePositions() const;

    /** Return current reference sample count. */
    [[nodiscard]] std::size_t AvailableReferenceSamples() const;

private:
    std::shared_ptr<AppendableReferenceBuffer> reference_buffer_;
};

/** Own one finite source window and controller state vectors. */
struct REFORGE_SHAPER_EXPORT TrajectoryWindow final {
    reforge::native::Matrix command;
    reforge::native::Matrix states;
    reforge::native::Matrix command_velocity;
    reforge::native::Matrix command_acceleration;
    reforge::native::Vector time_s;
    std::size_t start_index = 0;
    std::size_t stop_index = 0;
    std::optional<reforge::native::Vector> vibration_shaping_weight_profile;
    bool should_shape = true;
};

/** Own one shaped finite output window. */
struct REFORGE_SHAPER_EXPORT ShapedTrajectoryWindow final {
    reforge::native::Matrix positions;
    reforge::native::Matrix velocities;
    reforge::native::Matrix accelerations;
    reforge::native::Vector time_s;
    std::size_t start_index = 0;
    std::size_t stop_index = 0;
    bool is_tail = false;
    double compute_time_s = 0.0;
};

/** Validate one finite source trajectory window. */
REFORGE_SHAPER_EXPORT void ValidateTrajectoryWindow(
    const TrajectoryWindow& window);

/** Validate one finite shaped trajectory window. */
REFORGE_SHAPER_EXPORT void ValidateShapedTrajectoryWindow(
    const ShapedTrajectoryWindow& window);

/** Define the native lifted-MPC solve session used by its window adapter. */
class REFORGE_SHAPER_EXPORT LiftedMpcSolveSession {
public:
    virtual ~LiftedMpcSolveSession() = default;

    /** Prepare one controller solve session. */
    virtual void Prepare() = 0;

    /** Solve one owned reference slice and return an owned payload. */
    [[nodiscard]] virtual WindowPayload Solve(
        const WindowSlice& reference) = 0;

    /** Close the native solve session exactly once. */
    virtual void Close() = 0;
};

/** Adapt an appendable reference to one persistent native MPC solve session. */
class REFORGE_SHAPER_EXPORT AppendableLiftedMpcWindowProducer final
    : public WindowProducerSession {
public:
    /** Construct a stopped producer with fixed apply and lookahead lengths. */
    AppendableLiftedMpcWindowProducer(
        std::unique_ptr<LiftedMpcSolveSession> solve_session,
        std::shared_ptr<AppendableReferenceBuffer> reference_buffer,
        std::size_t apply_samples,
        std::size_t lookahead_samples,
        double sample_time_s,
        std::size_t start_index = 0);
    ~AppendableLiftedMpcWindowProducer() override;
    AppendableLiftedMpcWindowProducer(
        AppendableLiftedMpcWindowProducer&&) noexcept;
    AppendableLiftedMpcWindowProducer& operator=(
        AppendableLiftedMpcWindowProducer&&) noexcept;
    AppendableLiftedMpcWindowProducer(
        const AppendableLiftedMpcWindowProducer&) = delete;
    AppendableLiftedMpcWindowProducer& operator=(
        const AppendableLiftedMpcWindowProducer&) = delete;

    /** Prepare the persistent solve session and reset its source cursor. */
    void PrepareSession() override;

    /** Solve the next available apply range with terminal lookahead padding. */
    [[nodiscard]] std::optional<WindowPayload> ProduceNext() override;

    /** Return whether a finished reference has been completely consumed. */
    [[nodiscard]] bool IsExhausted() const override;

    /** Close the solve session and return no terminal output. */
    [[nodiscard]] std::optional<WindowPayload> Finalize() override;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace reforge::control::window
