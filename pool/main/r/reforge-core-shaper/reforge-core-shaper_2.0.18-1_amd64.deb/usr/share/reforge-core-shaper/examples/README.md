# Reforge Shaper C++ Demo

This demo builds against an installed `ReforgeShaper` CMake package and runs a
hardware-free Shaper runtime check.

From this directory after installing `reforge-core-shaper`:

```bash
cmake -S . -B build
cmake --build build --parallel
./build/reforge_shaper_demo
```

Successful output:

```text
Reforge Shaper C++ demo complete.
```
