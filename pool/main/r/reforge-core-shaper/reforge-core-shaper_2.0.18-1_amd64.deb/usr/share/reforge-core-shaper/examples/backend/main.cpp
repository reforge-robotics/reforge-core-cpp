#include <chrono>
#include <cmath>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>

#include "reforge_core/control/runtime/modal_inference.hpp"
#include "reforge_core/control/shaper/backend/native_shaper.hpp"

namespace {

using reforge::control::runtime::AxisParams;
using reforge::control::runtime::SharedImpulsePolicy;
using reforge::control::shaper::ResidualSwitchLimits;
using reforge::control::shaper::backend::BackendConfiguration;
using reforge::control::shaper::backend::NativeShaper;
using reforge::control::shaper::backend::ProcessTrajectoryRequest;
using reforge::native::Matrix;
using reforge::native::Vector;

/** Abort the demo when an expected backend invariant is false. */
void Require(bool condition, const char* message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

/** Return the temporary fixture directory for this process run. */
std::filesystem::path FixtureDirectory() {
    const auto now = std::chrono::steady_clock::now().time_since_epoch();
    const auto token =
        std::chrono::duration_cast<std::chrono::nanoseconds>(now).count();
    return std::filesystem::temp_directory_path() /
        ("reforge_shaper_backend_demo_" + std::to_string(token));
}

/** Write one deterministic two-axis model bundle and matching URDF. */
void WriteBackendFixtures(const std::filesystem::path& directory) {
    std::filesystem::create_directories(directory);

    std::ofstream urdf(directory / "robot.urdf");
    urdf << R"(<?xml version="1.0"?>
<robot name="reforge_backend_demo">
  <link name="base"/>
  <link name="link1">
    <inertial>
      <origin xyz="0.5 0 0"/>
      <mass value="1"/>
      <inertia ixx="0.01" ixy="0" ixz="0"
               iyy="0.10" iyz="0" izz="0.10"/>
    </inertial>
  </link>
  <link name="tool0">
    <inertial>
      <origin xyz="0.25 0 0"/>
      <mass value="0.5"/>
      <inertia ixx="0.005" ixy="0" ixz="0"
               iyy="0.02" iyz="0" izz="0.02"/>
    </inertial>
  </link>
  <joint name="joint0" type="revolute">
    <parent link="base"/>
    <child link="link1"/>
    <origin xyz="0 0 0"/>
    <axis xyz="0 0 1"/>
    <limit lower="-3.14" upper="3.14" effort="100" velocity="10"/>
  </joint>
  <joint name="joint1" type="revolute">
    <parent link="link1"/>
    <child link="tool0"/>
    <origin xyz="1 0 0"/>
    <axis xyz="0 0 1"/>
    <limit lower="-3.14" upper="3.14" effort="100" velocity="10"/>
  </joint>
</robot>
)";
    urdf.close();

    std::ofstream manifest(directory / "model_bundle.json");
    manifest << R"({
  "schema_version": 1,
  "model_type": "shaper_nn_v1",
  "num_axes": 2,
  "output_sensor": "arm_imu",
  "artifact_filenames": ["axis0_model.pt", "axis1_model.pt"],
  "native_artifact_schema_version": 1,
  "native_artifact_filename": "shaper_models.native.json",
  "feature_names": ["j0_rad", "j1_rad", "v_deg", "r_mm", "inertia"],
  "feature_units": ["rad", "rad", "deg", "mm", "kg_m2"],
  "input_feature_count": 5,
  "base_joint_count": 2,
  "base_joint_reference_angles": [0.0, 0.0],
  "calibration_schema_version": 2
})";
    manifest.close();

    std::ofstream artifact(directory / "shaper_models.native.json");
    artifact << R"({
  "schema": "reforge_shaper_weights",
  "version": 1,
  "scalar": "float32",
  "layout": "out_features_by_in_features",
  "feature_names": ["j0_rad", "j1_rad", "v_deg", "r_mm", "inertia"],
  "feature_units": ["rad", "rad", "deg", "mm", "kg_m2"],
  "input_feature_count": 5,
  "axes": [
    {
      "axis": 0,
      "layers": [],
      "order_head": {
        "kind": "linear_sigmoid_nan_to_num_clamp",
        "in_features": 5,
        "out_features": 1,
        "weight": [[0.0, 0.0, 0.0, 0.0, 0.0]],
        "bias": [2.0],
        "nan_replacement": 0.5,
        "clamp_min": 0.000001,
        "clamp_max": 0.999999
      },
      "mode_head": {
        "kind": "linear",
        "in_features": 5,
        "out_features": 4,
        "weight": [
          [0.0, 0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0, 0.0]
        ],
        "bias": [20.0, -2.3025851, 30.0, -1.6094379]
      }
    },
    {
      "axis": 1,
      "layers": [],
      "order_head": {
        "kind": "linear_sigmoid_nan_to_num_clamp",
        "in_features": 5,
        "out_features": 1,
        "weight": [[0.0, 0.0, 0.0, 0.0, 0.0]],
        "bias": [-2.0],
        "nan_replacement": 0.5,
        "clamp_min": 0.000001,
        "clamp_max": 0.999999
      },
      "mode_head": {
        "kind": "linear",
        "in_features": 5,
        "out_features": 4,
        "weight": [
          [0.0, 0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0, 0.0],
          [0.0, 0.0, 0.0, 0.0, 0.0]
        ],
        "bias": [25.0, -1.8971200, 35.0, -1.3862944]
      }
    }
  ]
})";
}

/** Return complete deterministic backend construction inputs. */
BackendConfiguration Configuration(const std::filesystem::path& directory) {
    BackendConfiguration configuration;
    configuration.sample_time_s = 0.01;
    configuration.model_directory = directory;
    configuration.urdf_filepath = directory / "robot.urdf";
    configuration.num_axes = 2;
    configuration.num_joints = 2;
    configuration.side_length_m = 1.0;
    configuration.base_height_m = 0.0;
    configuration.shared_impulse_policy = SharedImpulsePolicy::kPerAxis;
    configuration.shared_impulse_shapes_all_joints = false;
    configuration.train_base_angles_rad = Vector::Zero(2);
    return configuration;
}

/** Return fixed modal rows that keep the demo independent of Python. */
AxisParams FixedModes() {
    Matrix first(1, 2);
    first << 20.0, 0.1;
    Matrix second(1, 2);
    second << 25.0, 0.15;
    return {std::move(first), std::move(second)};
}

/** Exercise the installed complete backend target and residual solver path. */
void RunDemo() {
    const auto fixture_dir = FixtureDirectory();
    WriteBackendFixtures(fixture_dir);

    NativeShaper backend(Configuration(fixture_dir));
    Matrix command(12, 2);
    command.setZero();
    command.col(0) <<
        0.0, 0.1, 0.2, 0.3, 0.4, 0.5,
        0.6, 0.68, 0.74, 0.78, 0.8, 0.8;

    ResidualSwitchLimits limits;
    const Vector maximum = Vector::Constant(2, 1000.0);
    limits.max_velocity_rad_s = maximum;
    limits.max_acceleration_rad_s2 = maximum;
    limits.max_jerk_rad_s3 = maximum;
    limits.search_resolution_s = 0.01;
    limits.max_qp_attempts = 4;

    ProcessTrajectoryRequest request;
    request.input.position_rad = command;
    request.vibration_shaping_weight = 1.0;
    request.residual_transition_margin_s = 0.02;
    request.residual_switch_limits = limits;
    request.finalize_tail = true;
    request.fixed_modal_params_by_axis = FixedModes();

    const auto shaped = backend.ProcessTrajectory(request);
    Require(shaped.positions.rows() > command.rows(), "backend emits tail");
    Require(shaped.positions.cols() == command.cols(), "backend preserves axes");
    Require(
        backend.LastResidualSwitchDiagnostics().has_value(),
        "residual solver diagnostics are available");

    std::filesystem::remove_all(fixture_dir);
}

}  // namespace

/** Build and run one installed-SDK complete Shaper backend demonstration. */
int main() {
    try {
        RunDemo();
    } catch (const std::exception& error) {
        std::cerr << "Reforge Shaper backend demo failed: "
                  << error.what() << '\n';
        return 1;
    }

    std::cout << "Reforge Shaper backend demo complete.\n";
    return 0;
}
