# Reforge Shaper Backend Demo

This installed demo verifies that the complete Clarabel-backed Shaper C++ SDK
surface is consumable from a customer CMake project.

Build and run it after installing `reforge-core-shaper`:

```bash
cmake -S /usr/share/reforge-core-shaper/examples/backend \
  -B /tmp/reforge-shaper-backend-demo
cmake --build /tmp/reforge-shaper-backend-demo --parallel
/tmp/reforge-shaper-backend-demo/reforge_shaper_backend_demo
```

Expected output:

```text
Reforge Shaper backend demo complete.
```
