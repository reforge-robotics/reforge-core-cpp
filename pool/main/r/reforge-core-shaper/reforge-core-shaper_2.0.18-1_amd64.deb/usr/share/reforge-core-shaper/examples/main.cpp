#include <cmath>
#include <exception>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <vector>

#include "reforge_core/control/runtime/base_shaper.hpp"
#include "reforge_core/control/runtime/weighting.hpp"
#include "reforge_core/native/common/array_types.hpp"

namespace {

using reforge::control::runtime::BaseShaper;
using reforge::control::runtime::SharedAxisShaperSession;
using reforge::control::runtime::WeightingService;
using reforge::native::Matrix;
using reforge::native::Vector;

/** Return one physically valid modal row for a ZVD shaper. */
Matrix MakeModalParameters(double frequency_hz) {
    Matrix parameters(1, 2);
    parameters << 2.0 * std::acos(-1.0) * frequency_hz, 0.05;
    return parameters;
}

/** Abort the demo when an expected runtime invariant is false. */
void Require(bool condition, const char* message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

/** Exercise public Shaper runtime headers from an installed SDK. */
void RunDemo() {
    constexpr double kSampleTimeS = 0.01;
    BaseShaper scalar_shaper(kSampleTimeS);

    Vector command(8);
    command << 0.0, 0.2, 0.4, 0.6, 0.8, 0.6, 0.3, 0.0;

    std::vector<Matrix> modal_parameters;
    modal_parameters.reserve(static_cast<std::size_t>(command.size()));
    for (Eigen::Index sample = 0; sample < command.size(); ++sample) {
        modal_parameters.push_back(
            MakeModalParameters(4.0 + 0.1 * static_cast<double>(sample)));
    }

    const auto shaped = scalar_shaper.ShapeTrajectory(command, modal_parameters);
    Require(
        shaped.positions.rows() == command.rows(),
        "shaped trajectory has the expected sample count");
    Require(
        shaped.velocities.rows() == command.rows(),
        "shaped velocity has the expected sample count");
    Require(
        shaped.accelerations.rows() == command.rows(),
        "shaped acceleration has the expected sample count");
    Require(
        scalar_shaper.delay_samples() > 0,
        "ZVD shaper reports a positive active delay");

    const auto tail = scalar_shaper.Finalize(3);
    Require(tail.size() == 3, "finalize returns the requested tail length");

    WeightingService weighting(kSampleTimeS);
    const Vector weights = weighting.Profile(6, 0.25, 0.03);
    Require(weights.size() == 6, "weighting service emits all samples");
    Require(
        weights(0) >= weights(weights.size() - 1),
        "weight profile progresses monotonically toward the target");

    SharedAxisShaperSession shared_session(2, kSampleTimeS);
    Matrix shared_command(3, 2);
    shared_command << 0.0, 0.1,
        0.2, 0.3,
        0.4, 0.5;
    const std::vector<Matrix> shared_parameters(
        static_cast<std::size_t>(shared_command.rows()),
        MakeModalParameters(5.0));
    const auto shared = shared_session.ShapeTrajectory(
        shared_command,
        shared_parameters);
    Require(shared.positions.rows() == 3, "shared shaping preserves rows");
    Require(shared.positions.cols() == 2, "shared shaping preserves axes");
}

}  // namespace

/** Build and run one installed-SDK Shaper runtime demonstration. */
int main() {
    try {
        RunDemo();
    } catch (const std::exception& error) {
        std::cerr << "Reforge Shaper C++ demo failed: "
                  << error.what() << '\n';
        return 1;
    }

    std::cout << "Reforge Shaper C++ demo complete.\n";
    return 0;
}
