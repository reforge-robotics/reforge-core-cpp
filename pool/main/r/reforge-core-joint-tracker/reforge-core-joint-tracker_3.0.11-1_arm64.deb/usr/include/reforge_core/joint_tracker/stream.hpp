#pragma once

#include <cstddef>
#include <functional>
#include <memory>
#include <optional>
#include <vector>

#include "reforge_core/joint_tracker/config.hpp"
#include "reforge_core/joint_tracker/sample.hpp"
#include "reforge_core/joint_tracker/trajectory.hpp"

namespace reforge::joint_tracker {

namespace detail {
struct JointTrackerModelSnapshot;
struct StreamingOptimizerState;
}  // namespace detail

/** Store one emitted optimized Joint Tracker stream window and metadata. */
struct JointTrackerWindow final {
    /** Optimized command samples for this emitted window. */
    JointTrajectory trajectory;

    /** Inclusive global start sample index [samples]. */
    std::size_t start_index = 0;

    /** Exclusive global stop sample index [samples]. */
    std::size_t stop_index = 0;

    /** Nominal samples applied per native streaming solve [samples]. */
    std::size_t n_apply_samples = 0;

    /** Zero-based streaming solve index [count]. */
    std::size_t solve_index = 0;

    /** Inclusive global start sample index for the solve [samples]. */
    std::size_t solve_start_index = 0;

    /** Exclusive global stop sample index for the solve [samples]. */
    std::size_t solve_stop_index = 0;

    /** Temporary tail padding samples used to satisfy lookahead [samples]. */
    std::size_t terminal_padding_samples = 0;

    /** Held desired samples committed because planner lookahead underran. */
    std::size_t hold_samples_added = 0;
};

/** Synchronously consume one optimized stream window on the caller thread.
 *
 * The borrowed window is valid only for the duration of the callback. Copy any
 * data that must outlive the invocation.
 */
using JointTrackerWindowCallback =
    std::function<void(const JointTrackerWindow&)>;

/** Buffer appended reference samples for pass-through online consumption.
 *
 * Instances are not thread-safe. Callers must externally serialize all access,
 * including appends, pops, status reads, and callback dispatch.
 */
class JointTrackerStream final {
public:
    /** Construct a stream with the runtime settings used for validation. */
    explicit JointTrackerStream(
        JointTrackerConfig config,
        bool optimize_loaded_models = false);

    ~JointTrackerStream();

    JointTrackerStream(const JointTrackerStream&) = delete;
    JointTrackerStream& operator=(const JointTrackerStream&) = delete;
    JointTrackerStream(JointTrackerStream&&) noexcept;
    JointTrackerStream& operator=(JointTrackerStream&&) noexcept;

    /** Append one reference sample to the stream. */
    void AppendReferenceSample(JointSample sample);

    /** Append all samples from a reference trajectory to the stream. */
    void AppendReference(const JointTrajectory& trajectory);

    /** Mark the reference stream complete. */
    void Finish() noexcept;

    /** Return whether the producer has marked the stream complete. */
    [[nodiscard]] bool finished() const noexcept {
        return finished_;
    }

    /** Return the number of unread samples. */
    [[nodiscard]] std::size_t pending_sample_count() const noexcept {
        return buffer_.size() - read_index_;
    }

    /** Return the number of committed reference samples, including holds. */
    [[nodiscard]] std::size_t reference_sample_count() const noexcept {
        return total_committed_reference_samples_;
    }

    /** Return total committed hold samples caused by lookahead underruns. */
    [[nodiscard]] std::size_t hold_samples_added() const noexcept {
        return hold_samples_added_;
    }

    /** Pop one unread sample if one is available. */
    [[nodiscard]] std::optional<JointSample> PopSample();

    /** Pop one optimized stream window.
     *
     * `max_samples == 0` selects the native MPC `n_apply` window size when
     * models are loaded, or all pending pass-through samples otherwise.
     */
    [[nodiscard]] std::optional<JointTrackerWindow> PopWindow(
        std::size_t max_samples = 0);

    /** Pop and synchronously dispatch one optimized stream window.
     *
     * Returns `true` when a window was dispatched and `false` when no window is
     * currently available. The stream commits the window before invoking the
     * callback. If the callback throws, the exception propagates and the
     * window is not replayed. The callback must not re-enter this stream.
     *
     * The callback runs inline on the caller thread. A blocking robot-driver
     * callback therefore applies backpressure to this call.
     */
    bool PopWindowToCallback(
        const JointTrackerWindowCallback& stream_to_robot_callback,
        std::size_t max_samples = 0);

private:
    friend class JointTracker;

    JointTrackerStream(
        JointTrackerConfig config,
        bool optimize_loaded_models,
        std::shared_ptr<const detail::JointTrackerModelSnapshot>
            model_snapshot);

    void CompactConsumedSamples();

    JointTrackerConfig config_;
    std::vector<JointSample> buffer_;
    std::size_t inferred_joint_count_ = 0;
    std::size_t buffer_start_index_ = 0;
    std::size_t read_index_ = 0;
    std::size_t solve_index_ = 0;
    std::size_t total_committed_reference_samples_ = 0;
    std::size_t hold_samples_added_ = 0;
    std::vector<double> reference_offsets_rad_;
    std::optional<JointSample> terminal_sample_;
    bool finished_ = false;
    bool optimize_loaded_models_ = false;
    std::shared_ptr<const detail::JointTrackerModelSnapshot> model_snapshot_;
    std::unique_ptr<detail::StreamingOptimizerState> optimizer_state_;
};

}  // namespace reforge::joint_tracker
