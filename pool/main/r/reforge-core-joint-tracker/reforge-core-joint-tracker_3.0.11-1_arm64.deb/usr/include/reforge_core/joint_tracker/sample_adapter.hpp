#pragma once

#include <cstddef>
#include <deque>
#include <functional>
#include <optional>

#include "reforge_core/joint_tracker/sample.hpp"
#include "reforge_core/joint_tracker/stream.hpp"

namespace reforge::joint_tracker {

class JointTracker;

/** Synchronously consume one command sample on the caller thread.
 *
 * The borrowed sample is valid only for the duration of the callback. Copy any
 * data that must outlive the invocation.
 */
using JointTrackerCommandCallback = std::function<void(const JointSample&)>;

/** Report the one-sample adapter buffering state for integration diagnostics. */
struct JointTrackerSampleAdapterStatus final {
    /** Desired samples appended by the caller [samples]. */
    std::size_t desired_samples_appended = 0;

    /** Command samples emitted to the caller [samples]. */
    std::size_t command_samples_emitted = 0;

    /** Unread committed reference samples inside the wrapped stream [samples]. */
    std::size_t pending_reference_samples = 0;

    /** Command samples ready locally but not yet emitted [samples]. */
    std::size_t buffered_command_samples = 0;

    /** Committed reference samples, including stream-added holds [samples]. */
    std::size_t committed_reference_samples = 0;

    /** Held desired samples committed by planner-underrun fallback [samples]. */
    std::size_t hold_samples_added = 0;

    /** Whether the desired stream has been marked complete. */
    bool finished = false;
};

/** Adapt a Joint Tracker stream to a nonblocking one-sample control loop.
 *
 * Instances are not thread-safe. Callers must externally serialize all access,
 * including pushes, pops, status reads, finish, and callback dispatch.
 */
class JointTrackerSampleAdapter final {
public:
    /** Create an adapter over one tracker's stream.
     *
     * `readiness_samples` is the minimum unread reference lookahead required
     * before a non-finalized adapter emits another command sample. Use `1`
     * only when loop latency dominates. Larger values, typically near the
     * model impulse horizon, trade startup delay for commands closer to the
     * optimized windowed stream path.
     */
    explicit JointTrackerSampleAdapter(
        const JointTracker& tracker,
        std::size_t readiness_samples);

    /** Append one desired sample and return at most one command sample. */
    [[nodiscard]] std::optional<JointSample> PushDesiredSample(JointSample sample);

    /** Append one desired sample and dispatch at most one command sample.
     *
     * Returns `true` when the callback was invoked. The command is committed
     * before callback invocation, so a callback exception propagates without
     * replaying that command. The callback runs inline, must not re-enter this
     * adapter, and may block to provide driver backpressure.
     */
    bool PushDesiredSampleToCallback(
        JointSample sample,
        const JointTrackerCommandCallback& stream_to_robot_callback);

    /** Return at most one command sample without appending new desired input. */
    [[nodiscard]] std::optional<JointSample> PopCommandSample();

    /** Dispatch at most one buffered command sample to a synchronous callback.
     *
     * Returns `true` when the callback was invoked. Callback ownership,
     * exception, reentrancy, and backpressure semantics match
     * `PushDesiredSampleToCallback`.
     */
    bool PopCommandSampleToCallback(
        const JointTrackerCommandCallback& stream_to_robot_callback);

    /** Mark the desired stream complete so remaining buffered samples drain. */
    void Finish() noexcept;

    /** Return whether the desired stream has been marked complete. */
    [[nodiscard]] bool finished() const noexcept {
        return stream_.finished();
    }

    /** Return current adapter and wrapped-stream diagnostics. */
    [[nodiscard]] JointTrackerSampleAdapterStatus status() const noexcept;

private:
    void FillCommandQueue();

    JointTrackerStream stream_;
    std::deque<JointSample> command_queue_;
    std::size_t readiness_samples_ = 1;
    std::size_t desired_samples_appended_ = 0;
    std::size_t command_samples_emitted_ = 0;
};

}  // namespace reforge::joint_tracker
