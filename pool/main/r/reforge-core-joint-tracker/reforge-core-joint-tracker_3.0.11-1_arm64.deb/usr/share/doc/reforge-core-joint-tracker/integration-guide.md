# Reforge Joint Tracker C++ Integration Guide

Audience: a C++ engineer integrating Reforge Joint Tracker into a robot driver
or control application.

Joint Tracker consumes desired joint-space samples and returns compensated
joint-space command samples. It does not own transport, hardware state reads,
safety interlocks, or actuator communication.

The C++ SDK is robot-agnostic: customer code maps the returned joint command
samples to its own robot driver, safety policy, and timing contract.

```text
planner, playback, or teleoperation desired joint sample
  -> Reforge Joint Tracker
  -> robot driver joint command
```

## Build

Use the installed CMake package:

```cmake
cmake_minimum_required(VERSION 3.16)
project(my_robot_driver LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(ReforgeJointTracker CONFIG REQUIRED)

add_executable(my_robot_driver main.cpp)
target_link_libraries(
    my_robot_driver
    PRIVATE ReforgeJointTracker::joint_tracker
)
```

The public C++ API uses STL types. Installed public headers do not expose
Eigen, Python, Torch, OSQP, Shaper, or robot-vendor SDK types.

## Installed Smoke Test

After installing `reforge-core-joint-tracker`, build and run the installed
hardware-free demo:

```bash
cmake -S /usr/share/reforge-core-joint-tracker/examples \
  -B /tmp/reforge-joint-tracker-demo
cmake --build /tmp/reforge-joint-tracker-demo --parallel
/tmp/reforge-joint-tracker-demo/reforge_joint_tracker_driver_loop_demo
```

Expected output:

```text
Reforge Joint Tracker driver loop complete.
```

## Configure The Tracker

Configure the public facade with the joint count, modeled axes, and sample time.
Load a calibrated model bundle before commanding a calibrated robot.

```cpp
#include "reforge_core/joint_tracker/joint_tracker.hpp"

using reforge::joint_tracker::JointTracker;
using reforge::joint_tracker::JointTrackerConfig;

JointTrackerConfig config;
config.num_joints = 6;
config.modeled_axis_indices = {0, 1, 2, 3, 4, 5};
config.sample_time_s = 0.004;
config.optimizer_options.axis_workers = 3;

JointTracker tracker(config);
tracker.LoadModels("/path/to/joint_tracker/model_bundle");
```

The installed smoke-test demo omits `LoadModels` so package validation does not
depend on robot-specific calibration artifacts.

Joint Tracker always uses unpolished OSQP; there is no solver selector. The
default is three joined axis workers. `axis_workers` accepts 1 through 6, with
one worker providing serial execution when deployment topology requires it.

## Complete Trajectory

Use `OptimizeTrajectory` when the full desired trajectory is known before
execution starts.

```cpp
using reforge::joint_tracker::JointSample;
using reforge::joint_tracker::JointTrajectory;

std::vector<JointSample> desired_samples = BuildDesiredSamples();
JointTrajectory desired(desired_samples);
JointTrajectory command = tracker.OptimizeTrajectory(desired);

for (const JointSample& sample : command.samples()) {
    SendJointPositionCommand(sample.positions_rad);
}
```

## Known-Trajectory Streaming

Use `JointTrackerStream` when the trajectory is known but the caller wants to
consume command windows incrementally.

```cpp
auto stream = tracker.CreateStream();
stream.AppendReference(desired);
stream.Finish();

while (true) {
    auto window = stream.PopWindow(32);
    if (!window.has_value()) {
        break;
    }
    for (const JointSample& sample : window->trajectory.samples()) {
        SendJointPositionCommand(sample.positions_rad);
    }
}
```

## Online Planner Streaming

Use `AppendReferenceSample` when the planner produces desired samples while the
robot is already moving.

```cpp
auto stream = tracker.CreateStream();

while (planner_running) {
    JointSample desired_sample = planner.NextDesiredSample();
    stream.AppendReferenceSample(desired_sample);

    auto window = stream.PopWindow(16);
    if (window.has_value()) {
        for (const JointSample& command_sample : window->trajectory.samples()) {
            SendJointPositionCommand(command_sample.positions_rad);
        }
    }
}

stream.Finish();
```

## Sample-By-Sample Driver Loop

Use `JointTrackerSampleAdapter` when the caller's control loop naturally
pushes one desired sample and sends at most one command sample per iteration.

```cpp
#include "reforge_core/joint_tracker/sample_adapter.hpp"

using reforge::joint_tracker::JointTrackerSampleAdapter;

const std::size_t readiness_samples = 32;
JointTrackerSampleAdapter adapter(tracker, readiness_samples);

while (driver_enabled) {
    JointSample desired_sample = ReadDesiredJointSample();
    auto command = adapter.PushDesiredSample(desired_sample);
    if (command.has_value()) {
        SendJointPositionCommand(command->positions_rad);
    }
}

adapter.Finish();
while (auto command = adapter.PopCommandSample()) {
    SendJointPositionCommand(command->positions_rad);
}
```

For a synchronous driver API, the adapter can dispatch directly through a
callable instead of returning each command to the control loop:

```cpp
const auto stream_to_robot_callback =
    [&robot_driver](const JointSample& command) {
        robot_driver.set_arm_positions(
            command.positions_rad,
            0.0,
            false,
            command.velocities_rad_s.empty()
                ? std::nullopt
                : std::optional(command.velocities_rad_s),
            command.accelerations_rad_s2.empty()
                ? std::nullopt
                : std::optional(command.accelerations_rad_s2));
    };

while (driver_enabled) {
    adapter.PushDesiredSampleToCallback(
        ReadDesiredJointSample(), stream_to_robot_callback);
}

adapter.Finish();
while (adapter.PopCommandSampleToCallback(stream_to_robot_callback)) {
}
```

For a driver that accepts a trajectory or command batch, dispatch complete
native windows instead:

```cpp
auto stream = tracker.CreateStream();
stream.AppendReference(desired);
stream.Finish();

while (stream.PopWindowToCallback(
    [&robot_driver](const JointTrackerWindow& window) {
        robot_driver.SendJointTrajectory(window.trajectory);
    })) {
}
```

Callbacks run synchronously on the calling thread and receive a borrowed value
that is valid only during the invocation. The command or window is committed
before the callback runs. An exception propagates to the caller and the value is
not replayed, because the SDK cannot determine whether the robot driver already
performed a side effect. Do not re-enter the same stream or adapter from its
callback. A blocking callback applies backpressure to the caller.

Stream and adapter instances are not thread-safe. Externally serialize appends,
pops, status reads, finish calls, and callback dispatch on each instance.

The callback path can remove caller-side handoff and temporary plumbing, but it
does not shorten model optimization or the robot driver's transport latency.
Benchmark pull and callback modes with the production driver before selecting
one for latency reasons.

The approved Ubuntu 24.04/i7-1270P configuration, pinned to logical CPUs
`0,2,4,6` with three workers and readiness 1, is compute-qualified at 30 Hz:
active-bounds p99 was 11.382 ms with zero of 6,000 observations above 33.3 ms.
That hardware-free result does not include the driver call. Arrival-to-driver
return, 50 Hz zero-miss behavior, memory-budget, robot-motion, and production
qualification remain open. See the
[compute qualification record](../control/joint-tracker-compute-design.md).

`readiness_samples` is required. It is the lookahead threshold before the
adapter emits commands.

| `readiness_samples` | Observed behavior in the deterministic model-backed validation check |
| --- | --- |
| `1` | Lowest latency; steady-state output remains between `1e-2` and `3e-2` rad from the optimized windowed path. |
| `32` | Below `6e-4` rad from the optimized windowed path. |
| `64` | Below `4e-4` rad and closer than `32`. |

Start near the model impulse horizon when tracking accuracy matters more than
startup delay. Use `1` only when loop latency dominates.

## Driver Call Site

The Reforge SDK returns joint command samples. The customer application decides
how those samples map to its robot driver:

```cpp
void SendJointPositionCommand(const JointSample& command) {
    robot_driver.SendJointPositions(
        command.positions_rad,
        command.velocities_rad_s,
        command.accelerations_rad_s2,
        command.time_s);
}
```

Adapt that call to the robot driver's command API, safety policy, and timing
contract. Keep hardware-specific state handling outside the Reforge SDK.

## Source Build

Use the prebuilt APT package for the supported Ubuntu package path. Use a
source build for custom compilers, custom standard-library ABI choices, or
configurations outside that package path. Private Clarabel-symbol verification
applies only to supported, verified Linux SDK/wheel builds; this guide makes no
equivalent platform claim for other builds.

Joint Tracker still inherits a temporary shared build/link prerequisite on
Clarabel even though its runtime path is fixed to OSQP. Before configuring,
materialize the repository-locked Clarabel sources and build its C adapter with
Rust 1.84.1. Choose a writable dependency directory; the same directory is used
by the CMake configure command below. This prerequisite does not make Clarabel
selectable through the Joint Tracker API.

```bash
rustup toolchain install 1.84.1
cmake \
  -DREFORGE_SHAPER_DEPS_ROOT=/tmp/reforge-joint-tracker-deps \
  -P src/core_sdk/native/cmake/MaterializeClarabel.cmake
RUSTUP_TOOLCHAIN=1.84.1 cargo build \
  --manifest-path /tmp/reforge-joint-tracker-deps/Clarabel.cpp/rust_wrapper/Cargo.toml \
  --release --locked --no-default-features
```

```bash
cmake -S src/core_sdk/native -B build-joint-tracker \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_SHARED_LIBS=ON \
  -DREFORGE_BUILD_SHAPER=OFF \
  -DREFORGE_BUILD_JOINT_TRACKER=ON \
  -DREFORGE_JOINT_TRACKER_BUILD_PYTHON_BINDINGS=OFF \
  -DREFORGE_SHAPER_CLARABEL_ROOT=/tmp/reforge-joint-tracker-deps/Clarabel.cpp \
  -DREFORGE_NLOHMANN_JSON_INCLUDE_DIR=/path/to/nlohmann_json/include
cmake --build build-joint-tracker --parallel
cmake --install build-joint-tracker --prefix /opt/reforge
```
