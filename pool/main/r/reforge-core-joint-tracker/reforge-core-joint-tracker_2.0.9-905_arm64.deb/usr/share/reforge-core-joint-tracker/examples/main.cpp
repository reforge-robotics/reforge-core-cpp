#include <algorithm>
#include <cstdlib>
#include <exception>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "reforge_core/joint_tracker/joint_tracker.hpp"
#include "reforge_core/joint_tracker/sample_adapter.hpp"

namespace {

using reforge::joint_tracker::JointSample;
using reforge::joint_tracker::JointTracker;
using reforge::joint_tracker::JointTrackerConfig;
using reforge::joint_tracker::JointTrackerSampleAdapter;
using reforge::joint_tracker::JointTrackerStream;
using reforge::joint_tracker::JointTrajectory;

constexpr std::size_t kNumJoints = 6;
constexpr double kSampleTimeS = 0.004;
constexpr std::size_t kReadinessSamples = 32;

/** Store commands that would be sent to a robot driver. */
class MockRobotDriver final {
public:
    /** Store one command sample exactly as a driver send call would receive it. */
    void SendJointPositionCommand(const JointSample& command) {
        if (command.positions_rad.size() != kNumJoints) {
            throw std::runtime_error("command joint count mismatch");
        }
        sent_positions_rad_.push_back(command.positions_rad);
        sent_time_s_.push_back(command.time_s);
    }

    /** Return the number of command samples sent to the mock driver. */
    [[nodiscard]] std::size_t sent_count() const noexcept {
        return sent_positions_rad_.size();
    }

    /** Return one sent command timestamp [s]. */
    [[nodiscard]] double sent_time_s(std::size_t index) const {
        return sent_time_s_.at(index);
    }

private:
    std::vector<std::vector<double>> sent_positions_rad_;
    std::vector<double> sent_time_s_;
};

/** Abort the demo when a required condition is false. */
void Require(bool condition, const std::string& message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

/** Return one deterministic six-joint desired sample. */
JointSample MakeDesiredSample(std::size_t index) {
    const double step = static_cast<double>(index);
    JointSample sample;
    sample.time_s = step * kSampleTimeS;
    sample.positions_rad = {
        0.010 * step,
        -0.006 * step,
        0.004 * step,
        -0.003 * step,
        0.002 * step,
        -0.001 * step,
    };
    return sample;
}

/** Return one deterministic desired trajectory. */
JointTrajectory MakeDesiredTrajectory(std::size_t sample_count) {
    std::vector<JointSample> samples;
    samples.reserve(sample_count);
    for (std::size_t index = 0; index < sample_count; ++index) {
        samples.push_back(MakeDesiredSample(index));
    }
    return JointTrajectory(std::move(samples));
}

/** Return a release-1 tracker for the demo's six-joint command stream. */
JointTracker MakeTracker() {
    JointTrackerConfig config;
    config.num_joints = kNumJoints;
    config.modeled_axis_indices = {0, 1, 2, 3, 4, 5};
    config.sample_time_s = kSampleTimeS;
    return JointTracker(config);
}

/** Exercise the complete-trajectory upload API. */
void RunFullTrajectoryUpload(
    const JointTracker& tracker,
    const JointTrajectory& desired) {
    const JointTrajectory command = tracker.OptimizeTrajectory(desired);
    Require(
        command.sample_count() == desired.sample_count(),
        "full trajectory sample count changed");
    Require(
        command.joint_count() == desired.joint_count(),
        "full trajectory joint count changed");
}

/** Exercise the known-trajectory streaming API. */
void RunKnownTrajectoryStream(
    const JointTracker& tracker,
    const JointTrajectory& desired) {
    JointTrackerStream stream = tracker.CreateStream();
    stream.AppendReference(desired);
    stream.Finish();

    std::size_t emitted = 0;
    while (true) {
        const auto window = stream.PopWindow(16);
        if (!window.has_value()) {
            break;
        }
        emitted += window->trajectory.sample_count();
    }
    Require(
        emitted == desired.sample_count(),
        "known stream emitted the wrong sample count");
}

/** Exercise an online-planner append loop. */
void RunOnlinePlannerStream(
    const JointTracker& tracker,
    const JointTrajectory& desired) {
    constexpr std::size_t kInitialSamples = 12;
    constexpr std::size_t kAppendSamples = 10;
    constexpr std::size_t kLowWatermarkSamples = 4;

    JointTrackerStream stream = tracker.CreateStream();
    std::size_t appended = 0;
    const auto& desired_samples = desired.samples();
    while (appended < kInitialSamples && appended < desired_samples.size()) {
        stream.AppendReferenceSample(desired_samples.at(appended));
        ++appended;
    }

    std::size_t emitted = 0;
    while (true) {
        const auto window = stream.PopWindow(8);
        if (!window.has_value()) {
            if (stream.finished()) {
                break;
            }
        } else {
            emitted += window->trajectory.sample_count();
        }

        if (
            appended < desired_samples.size() &&
            stream.pending_sample_count() <= kLowWatermarkSamples) {
            const std::size_t next_stop = std::min(
                appended + kAppendSamples,
                desired_samples.size());
            for (; appended < next_stop; ++appended) {
                stream.AppendReferenceSample(desired_samples.at(appended));
            }
        }
        if (appended == desired_samples.size() && !stream.finished()) {
            stream.Finish();
        }
    }

    Require(
        emitted == desired.sample_count(),
        "online stream emitted the wrong sample count");
}

/** Exercise the one-sample control-loop adapter. */
void RunOneSampleDriverLoop(
    const JointTracker& tracker,
    const JointTrajectory& desired) {
    JointTrackerSampleAdapter adapter(tracker, kReadinessSamples);
    MockRobotDriver driver;

    for (const JointSample& desired_sample : desired.samples()) {
        const std::optional<JointSample> command =
            adapter.PushDesiredSample(desired_sample);
        if (command.has_value()) {
            driver.SendJointPositionCommand(*command);
        }
    }

    adapter.Finish();
    while (true) {
        const std::optional<JointSample> command = adapter.PopCommandSample();
        if (!command.has_value()) {
            break;
        }
        driver.SendJointPositionCommand(*command);
    }

    Require(
        driver.sent_count() == desired.sample_count(),
        "mock driver sent the wrong sample count");
    for (std::size_t index = 1; index < driver.sent_count(); ++index) {
        Require(
            driver.sent_time_s(index) > driver.sent_time_s(index - 1),
            "mock driver command timestamps must increase");
    }
}

/** Run every customer-facing release-1 call pattern. */
void RunDemo() {
    const JointTracker tracker = MakeTracker();
    const JointTrajectory desired = MakeDesiredTrajectory(96);

    RunFullTrajectoryUpload(tracker, desired);
    RunKnownTrajectoryStream(tracker, desired);
    RunOnlinePlannerStream(tracker, desired);
    RunOneSampleDriverLoop(tracker, desired);
}

}  // namespace

/** Build and run a hardware-free Joint Tracker driver-loop demo. */
int main() {
    try {
        RunDemo();
    } catch (const std::exception& error) {
        std::cerr << "Reforge Joint Tracker driver loop failed: "
                  << error.what() << '\n';
        return EXIT_FAILURE;
    }

    std::cout << "Reforge Joint Tracker driver loop complete.\n";
    return EXIT_SUCCESS;
}
