#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace reforge::joint_tracker {

/** Store release-1 Joint Tracker runtime settings with STL-only fields. */
struct JointTrackerConfig final {
    /** Number of controlled joints. A value of 0 defers validation. */
    std::size_t num_joints = 0;

    /** Physical joint axes backed by persisted joint-controller models. */
    std::vector<int> modeled_axis_indices;

    /** Uniform controller sample period [s]. */
    double sample_time_s = 0.0;

    /** Prediction window length [samples]. A value of 0 selects pass-through. */
    std::size_t prediction_horizon_samples = 0;

    /** Optional model directory path used by later model-loading phases. */
    std::string model_directory;
};

}  // namespace reforge::joint_tracker
