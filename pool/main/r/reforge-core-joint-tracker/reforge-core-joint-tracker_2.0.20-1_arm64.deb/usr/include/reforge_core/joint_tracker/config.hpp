#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace reforge::joint_tracker {

/** Store native lifted-MPC tuning values exposed through the low-level API. */
struct JointTrackerOptimizerOptions final {
    /** Input-effort regularization weight [unitless]. */
    double lam_u = 1.0e-2;

    /** Scale factor on reference peak used to build command bounds. */
    double input_bound_scale = 2.0;

    /** Fraction of the estimated horizon applied before re-solving. */
    double n_apply_scale = 0.75;

    /** Fraction of the impulse horizon used to seed apply-window sizing. */
    double n_apply_horizon_scale = 1.0;

    /** Whether streaming command windows blend against previous plans. */
    bool is_command_window_overlap_enabled = false;

    /** Fraction of the apply window used for command handoff overlap. */
    double window_overlap_scale = 0.5;

    /** Window length for optional output first-difference smoothing [samples]. */
    int output_du_smoothing_window_samples = 0;

    /** Moving-average window used for impulse-horizon estimation [samples]. */
    int moving_avg_window_samples = 25;

    /** Near-zero threshold ratio relative to impulse peak amplitude. */
    double zero_tol_ratio = 1.0e-5;

    /** Required consecutive near-zero samples for settling [samples]. */
    int settle_consecutive_samples = 20;

    /** Maximum impulse-response samples simulated for horizon estimation. */
    int max_impulse_samples = 5000;

    /** Command basis mode: "identity" or "truncated_svd". */
    std::string basis_mode = "identity";

    /** Target TSVD tracking metric used to select retained basis count. */
    double basis_target_je = 0.1;

    /** Whether `basis_max_jc` constrains retained TSVD basis count. */
    bool basis_max_jc_enabled = false;

    /** Optional maximum TSVD control-effort metric. */
    double basis_max_jc = 0.0;

    /** Minimum retained TSVD basis functions [count]. */
    int basis_min_count = 1;

    /** Optional maximum retained TSVD basis functions; 0 means no cap. */
    int basis_max_count = 0;

    /** Coefficient regularization in reduced TSVD mode. */
    double basis_lam_c = 1.0e-6;

    /** Reconstructed-command first-difference regularization. */
    double basis_lam_du = 0.0;

    /** Reconstructed-command second-difference regularization. */
    double basis_lam_ddu = 0.0;
};

/** Store release-1 Joint Tracker runtime settings with STL-only fields. */
struct JointTrackerConfig final {
    /** Number of controlled joints. A value of 0 defers validation. */
    std::size_t num_joints = 0;

    /** Physical joint axes backed by persisted joint-controller models. */
    std::vector<int> modeled_axis_indices;

    /** Uniform controller sample period [s]. */
    double sample_time_s = 0.0;

    /** Optional model directory path used by later model-loading phases. */
    std::string model_directory;

    /** Native optimizer tuning options. */
    JointTrackerOptimizerOptions optimizer_options;
};

}  // namespace reforge::joint_tracker
