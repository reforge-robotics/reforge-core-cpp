# Reforge Core Joint Tracker C++ SDK

Package: `reforge-core-joint-tracker`
Version: `2.0.18-1`
Architecture: `amd64/x86_64`

This package installs the Reforge Joint Tracker C++ shared
library, STL-only public headers, CMake package files,
robot-agnostic integration documentation, and a hardware-free
driver-loop demo.

Supported baseline: Ubuntu 20.04 or newer on amd64/x86_64, using the
customer system compiler and standard library at runtime.

Build and run the installed demo with:

```bash
cmake -S /usr/share/reforge-core-joint-tracker/examples -B /tmp/reforge-joint-tracker-demo
cmake --build /tmp/reforge-joint-tracker-demo --parallel
/tmp/reforge-joint-tracker-demo/reforge_joint_tracker_driver_loop_demo
```

The expected success line is:

```text
Reforge Joint Tracker driver loop complete.
```
